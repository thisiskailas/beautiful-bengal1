/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Ship } from 'lucide-react';
import { Language, VesselSchedule } from '../types';
import { DICTIONARY } from '../data';

interface FerrySchedulesProps {
  lang: Language;
  isAdmin: boolean;
  schedules: VesselSchedule[];
  setSchedules: React.Dispatch<React.SetStateAction<VesselSchedule[]>>;
}

export default function FerrySchedules({ lang }: FerrySchedulesProps) {
  return (
    <section id="ferry-section" className="py-20 bg-[#FCF9F5] dark:bg-stone-900 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center justify-center min-h-[40vh]">
        <Ship className="h-20 w-20 text-[#A22D22] dark:text-amber-400 mb-6 opacity-30" />
        <h2 className="font-heading text-4xl font-extrabold text-[#A22D22] dark:text-[#DF961A] sm:text-5xl tracking-widest uppercase">
          Coming Soon.......
        </h2>
        <p className="mt-4 text-stone-500 dark:text-stone-400 font-serif italic max-w-lg">
          {lang === 'en' ? 'The Kakdwip subdivision inland water transportation and timetable schedules are currently under construction.' : 'কাকদ্বীপ মহকুমা ভেসেল ও ফেরি সময়সূচি বর্তমানে নির্মাণাধীন রয়েছে।'}
        </p>
      </div>
    </section>
  );
}
