/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Compass, Sparkles, AlertCircle } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY } from '../data';

interface HeroProps {
  lang: Language;
  onExplore: () => void;
  onUpdates: () => void;
}

const HERO_SLIDES = [
  {
    image: 'https://images.unsplash.com/photo-1555899434-94d1368aa7af?q=80&w=1600&auto=format&fit=crop',
    title: 'Himalayan Wonderland',
    titleBn: 'হিমালয়ের স্বর্গভূমি',
    location: 'Darjeeling Hills',
    locationBn: 'দার্জিলিং পর্বতমালা'
  },
  {
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?q=80&w=1600&auto=format&fit=crop',
    title: 'Monuments of Heritage',
    titleBn: 'ঐতিহ্যবাহী ঐতিহাসিক কৃষ্টি',
    location: 'Victoria Memorial, Kolkata',
    locationBn: 'ভিক্টোরিয়া মেমোরিয়াল, কলকাতা'
  },
  {
    image: 'https://images.unsplash.com/photo-1616160975936-7c050217be8a?q=80&w=1600&auto=format&fit=crop',
    title: 'Mystical Green Rivers',
    titleBn: 'রহস্যময় চিরসবুজ অরণ্য ও নদী',
    location: 'Sundarbans Biosphere',
    locationBn: 'সুন্দরবন ম্যানগ্রোভ বন'
  },
  {
    image: 'https://images.unsplash.com/photo-1545562083-a600704fa487?q=80&w=1600&auto=format&fit=crop',
    title: 'Serene Bay Coastline',
    titleBn: 'অনন্য সমুদ্র সৈকত',
    location: 'Digha Beach Shoreline',
    locationBn: 'দিঘা বেলাভূমি'
  }
];

export default function Hero({ lang, onExplore, onUpdates }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const d = DICTIONARY[lang];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, []);

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  return (
    <div className="relative h-[80vh] min-h-[500px] w-full overflow-hidden bg-stone-900" id="hero-section">
      
      {/* Background Images with dynamic opacity transforms */}
      {HERO_SLIDES.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-all duration-1000 ease-in-out ${
            index === currentSlide ? 'opacity-100 scale-102' : 'opacity-0 scale-100 pointer-events-none'
          }`}
        >
          <div className="absolute inset-0 bg-black/45 z-10" />
          <img
            src={slide.image}
            alt={slide.title}
            className="h-full w-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          {/* Tagline Indicator */}
          <div className="absolute bottom-6 left-6 z-20 hidden xs:flex items-center gap-2 rounded-full bg-black/60 px-3.5 py-1.5 text-xs text-stone-200 backdrop-blur-md">
            <span className="h-2 w-2 rounded-full bg-[#DF961A] animate-pulse" />
            <span>{lang === 'en' ? slide.location : slide.locationBn}</span>
          </div>
        </div>
      ))}

      {/* Floating Cultural Colors Border */}
      <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-[#A22D22] via-[#DF961A] to-amber-500 z-30" />

      {/* Inner Hero Content */}
      <div className="absolute inset-x-0 bottom-0 top-0 z-20 flex flex-col items-center justify-center px-4 text-center sm:px-6">
        <div className="max-w-4xl space-y-6">
          
          <div className="inline-flex items-center gap-1.5 rounded-full bg-rose-600/25 border border-red-500/30 px-4 py-1 text-xs font-bold text-amber-200 animate-bounce">
            <Sparkles className="h-3.5 w-3.5" />
            <span>{d.slogan}</span>
          </div>

          <h2 className="font-heading text-4xl font-black tracking-tight text-white sm:text-5xl md:text-6xl uppercase lg:leading-tight">
            {d.welcome}
          </h2>

          <p className="mx-auto max-w-2xl text-lg text-stone-200 drop-shadow-md sm:text-xl">
            {d.heroSub}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={onExplore}
              id="hero-explore-btn"
              className="group flex w-full sm:w-auto items-center justify-center gap-2 rounded-full bg-[#A22D22] px-8 py-4 text-sm font-bold text-white shadow-xl hover:bg-[#832018] dark:bg-amber-500 dark:text-stone-950 dark:hover:bg-amber-400 transition-all duration-300"
            >
              <Compass className="h-4 w-4 group-hover:rotate-45 transition-transform" />
              <span>{d.exploreButton}</span>
            </button>

            <button
              onClick={onUpdates}
              id="hero-updates-btn"
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-full bg-white/10 px-8 py-4 text-sm font-bold text-white backdrop-blur-md hover:bg-white/20 border border-white/20 transition-all duration-300"
            >
              <AlertCircle className="h-4 w-4 animate-pulse" />
              <span>{d.updatesButton}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={handlePrev}
        id="hero-prev-btn"
        className="absolute left-4 top-1/2 z-20 -translate-y-1/2 rounded-full bg-black/35 p-3 text-white backdrop-blur-md hover:bg-black/65 transition-all"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <button
        onClick={handleNext}
        id="hero-next-btn"
        className="absolute right-4 top-1/2 z-20 -translate-y-1/2 rounded-full bg-black/35 p-3 text-white backdrop-blur-md hover:bg-black/65 transition-all"
        aria-label="Next slide"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      {/* Pagination bullets */}
      <div className="absolute bottom-12 left-1/2 z-20 flex -translate-x-1/2 gap-2">
        {HERO_SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2.5 rounded-full transition-all duration-300 ${
              idx === currentSlide ? 'w-8 bg-[#DF961A]' : 'w-2.5 bg-white/40'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>

    </div>
  );
}
