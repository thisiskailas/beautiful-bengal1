/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Newspaper, Search, Eye, Filter, Edit, Trash2, Heart, PlusCircle, Calendar, User, BookOpen, Clock, X } from 'lucide-react';
import { Language, BlogPost } from '../types';
import { DICTIONARY } from '../data';

interface UpdateCenterProps {
  lang: Language;
  isAdmin: boolean;
  blogs: BlogPost[];
  setBlogs: React.Dispatch<React.SetStateAction<BlogPost[]>>;
}

export default function UpdateCenter({ lang, isAdmin, blogs, setBlogs }: UpdateCenterProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [readingPost, setReadingPost] = useState<BlogPost | null>(null);

  // Add / Edit Blog Form State
  const [showForm, setShowForm] = useState(false);
  const [editingBlogId, setEditingBlogId] = useState<string | null>(null);

  // Form Fields
  const [formTitle, setFormTitle] = useState('');
  const [formTitleBn, setFormTitleBn] = useState('');
  const [formExcerpt, setFormExcerpt] = useState('');
  const [formExcerptBn, setFormExcerptBn] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formContentBn, setFormContentBn] = useState('');
  const [formCategory, setFormCategory] = useState<any>('Travel');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formAuthor, setFormAuthor] = useState('Kailas Halder');

  const d = DICTIONARY[lang];

  const categories = [
    'All',
    'Travel',
    'History',
    'Festivals',
    'Sweets',
    'Local Update',
    'Ferry',
    'Photography'
  ];

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid triggering card click
    setBlogs(prev => prev.map(post => {
      if (post.id === id) {
        return { ...post, likes: post.likes + 1 };
      }
      return post;
    }));
  };

  const handleInitCreate = () => {
    setEditingBlogId(null);
    setShowForm(true);
    setFormTitle('');
    setFormTitleBn('');
    setFormExcerpt('');
    setFormExcerptBn('');
    setFormContent('');
    setFormContentBn('');
    setFormCategory('Travel');
    setFormImageUrl('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=600');
    setFormAuthor('Kailas Halder');
  };

  const handleInitEdit = (post: BlogPost, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingBlogId(post.id);
    setShowForm(true);
    setFormTitle(post.title);
    setFormTitleBn(post.titleBn);
    setFormExcerpt(post.excerpt);
    setFormExcerptBn(post.excerptBn);
    setFormContent(post.content);
    setFormContentBn(post.contentBn);
    setFormCategory(post.category);
    setFormImageUrl(post.imageUrl);
    setFormAuthor(post.author);
  };

  const handleDeletePost = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(lang === 'en' ? 'Are you sure you want to delete this blog/update post?' : 'আপনি কি সত্যিই এই খবর/ব্লগ পোস্ট ডিলিট করতে চান?')) {
      setBlogs(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleSavePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formTitleBn || !formContent || !formContentBn) {
      alert(lang === 'en' ? 'Titles and Contents are required in both English and Bengali.' : 'ইংরেজি ও বাংলা উভয় ভাষায় শিরোনাম ও বিস্তারিত বিবরণ লিখতে হবে।');
      return;
    }

    const categoryBnMap: Record<string, string> = {
      'Travel': 'ভ্রমণ গাইড',
      'History': 'ইতিহাস ও হেরিটেজ',
      'Festivals': 'উৎসব ও মেলা',
      'Sweets': 'বাংলার রকমারি মিষ্টি',
      'Local Update': 'স্থানীয় ঘোষণা',
      'Ferry': 'ফেরি চলাচল আপডেট',
      'Photography': 'বাংলা ফোটোগ্রাফি'
    };

    if (editingBlogId) {
      // Edit post
      setBlogs(prev => prev.map(p => {
        if (p.id === editingBlogId) {
          return {
            ...p,
            title: formTitle,
            titleBn: formTitleBn,
            excerpt: formExcerpt || formTitle.slice(0, 100) + '...',
            excerptBn: formExcerptBn || formTitleBn.slice(0, 100) + '...',
            content: formContent,
            contentBn: formContentBn,
            category: formCategory,
            categoryBn: categoryBnMap[formCategory] || 'অন্যান্য',
            imageUrl: formImageUrl || 'https://images.unsplash.com/photo-1545562083-a600704fa487?q=80&w=600',
            author: formAuthor,
            publishDate: p.publishDate // Keep original
          };
        }
        return p;
      }));
    } else {
      // Add post
      const newPost: BlogPost = {
        id: 'blog-' + Date.now(),
        title: formTitle,
        titleBn: formTitleBn,
        excerpt: formExcerpt || formTitle.slice(0, 100) + '...',
        excerptBn: formExcerptBn || formTitleBn.slice(0, 100) + '...',
        content: formContent,
        contentBn: formContentBn,
        category: formCategory,
        categoryBn: categoryBnMap[formCategory] || 'অন্যান্য',
        imageUrl: formImageUrl || 'https://images.unsplash.com/photo-1545562083-a600704fa487?q=80&w=600',
        author: formAuthor,
        publishDate: new Date().toISOString().split('T')[0],
        likes: 0
      };
      setBlogs(prev => [newPost, ...prev]);
    }

    setShowForm(false);
    setEditingBlogId(null);
  };

  const filteredBlogs = blogs.filter(post => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.titleBn.includes(searchQuery) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerptBn.includes(searchQuery);

    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <section id="blogs-section" className="py-20 bg-white dark:bg-stone-950 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Module Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gap-6">
          <div className="space-y-2">
            <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block flex items-center gap-1">
              <Newspaper className="h-4 w-4" />
              <span>{lang === 'en' ? 'CMS Portal Newsroom' : 'গণমাধ্যম ও খবর কেন্দ্র'}</span>
            </span>
            <h2 className="font-heading text-3xl font-extrabold text-stone-900 dark:text-neutral-50 sm:text-4xl">
              {lang === 'en' ? 'Daily Bengal Bulletins & Blogs' : 'দৈনিক আপডেট ও পর্যটন ব্লগ'}
            </h2>
          </div>

          {/* Search bar inside CMS */}
          <div className="flex items-center gap-2">
            <div className="relative w-72">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-stone-400">
                <Search className="h-4 w-4" />
              </span>
              <input
                type="text"
                placeholder={lang === 'en' ? 'Search updates or blogs...' : 'খবর বা ব্লগ খুঁজুন...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-full border border-orange-100 bg-[#FCF9F5] pl-10 pr-4 py-2 text-sm text-stone-900 dark:border-stone-800 dark:bg-stone-900 dark:text-white"
              />
            </div>
            
            {isAdmin && !showForm && (
              <button
                onClick={handleInitCreate}
                id="add-new-post-btn"
                className="flex items-center gap-1.5 rounded-full bg-[#A22D22] text-white hover:bg-[#832018] px-4 py-2 text-xs font-bold shadow-md dark:bg-amber-500 dark:text-stone-950 dark:hover:bg-amber-400"
              >
                <PlusCircle className="h-4 w-4" />
                <span>{lang === 'en' ? 'Write Post' : 'নতুন পোস্ট'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Categories Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 mb-8 border-b border-orange-50 pb-4 dark:border-stone-900">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`rounded-full px-3.5 py-1.5 text-xs font-semibold tracking-wide transition-all ${
                activeCategory === cat
                  ? 'bg-rose-900 text-white shadow-xs dark:bg-amber-500 dark:text-stone-950 font-bold'
                  : 'bg-[#FCF9F5] text-stone-600 hover:bg-stone-100 border border-orange-50 dark:bg-stone-900 dark:text-stone-300 dark:border-stone-800 dark:hover:bg-stone-800'
              }`}
            >
              {cat === 'All' ? d.categoryAll : cat}
            </button>
          ))}
        </div>

        {/* CMS Input Form Drawer */}
        {showForm && (
          <div className="mb-12 overflow-hidden rounded-2xl border border-dashed border-[#DF961A] p-6 bg-orange-50/10 dark:bg-stone-900/40 dark:border-stone-800 animate-in slide-in-from-top duration-300">
            <h3 className="font-heading text-lg font-extrabold text-stone-900 dark:text-stone-50 mb-4 flex items-center gap-1.5">
              <BookOpen className="h-5 w-5 text-[#A22D22] dark:text-amber-400" />
              <span>{editingBlogId ? d.editPost : d.addPost}</span>
            </h3>

            <form onSubmit={handleSavePost} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Post Title (English)</label>
                  <input
                    type="text"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    placeholder="e.g. New Ferry Schedule Active for Monsoons"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">পোস্ট টাইটেল (বাংলা)</label>
                  <input
                    type="text"
                    value={formTitleBn}
                    onChange={(e) => setFormTitleBn(e.target.value)}
                    className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    placeholder="উদা: বর্ষার জন্য বিশেষ ভেসেল সময়সূচি"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Short Excerpt (English)</label>
                  <input
                    type="text"
                    value={formExcerpt}
                    onChange={(e) => setFormExcerpt(e.target.value)}
                    className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    placeholder="Brief description about this update..."
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">সংক্ষিপ্ত বিবরণ (বাংলা)</label>
                  <input
                    type="text"
                    value={formExcerptBn}
                    onChange={(e) => setFormExcerptBn(e.target.value)}
                    className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    placeholder="এই খবরের ছোট্ট সারাংশ..."
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Image URL</label>
                  <input
                    type="url"
                    value={formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    placeholder="Copy/paste a tourism photo URL..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Category</label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as any)}
                      className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    >
                      {categories.filter(c => c !== 'All').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Author Name</label>
                    <input
                      type="text"
                      value={formAuthor}
                      onChange={(e) => setFormAuthor(e.target.value)}
                      className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-850 dark:bg-stone-800 dark:text-white"
                    />
                  </div>
                </div>

              </div>

              <div>
                <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">Detailed Content (English) - Markdown friendly</label>
                <textarea
                  rows={4}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-855 dark:bg-stone-800 dark:text-white"
                  placeholder="Complete travel guide descriptions, timetables, local facts..."
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1">বিস্তারিত বিবরণ (বাংলা)</label>
                <textarea
                  rows={4}
                  value={formContentBn}
                  onChange={(e) => setFormContentBn(e.target.value)}
                  className="w-full rounded-lg border border-orange-100 bg-white px-3 py-2 text-sm text-stone-900 dark:border-stone-855 dark:bg-stone-800 dark:text-white"
                  placeholder="বিস্তারিত বিবরণ, ভ্রমণের সময়সূচি ও স্থানীয় তথ্যাদি..."
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-stone-200/50 dark:border-stone-800">
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingBlogId(null);
                  }}
                  className="px-4 py-2 text-xs font-semibold text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200"
                >
                  {d.cancel}
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-[#A22D22] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#832018] dark:bg-amber-500 dark:text-stone-950 dark:hover:bg-amber-400 transition-colors"
                >
                  {d.save}
                </button>
              </div>

            </form>
          </div>
        )}

        {/* Blogs Grid Output */}
        {filteredBlogs.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-stone-200 dark:border-stone-850 rounded-2xl bg-[#FCF9F5]">
            <p className="text-sm font-semibold text-stone-600 dark:text-stone-450">
              {lang === 'en' ? 'No bulletins or stories match your category and search criteria.' : 'দুঃখিত, এই বিভাগে বর্তমানে কোনো নতুন খবর প্রকাশ করা হয়নি।'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="blogs-grid">
            {filteredBlogs.map((post) => (
              <article
                key={post.id}
                id={`blog-card-${post.id}`}
                onClick={() => setReadingPost(post)}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl bg-[#FCF9F5] border border-orange-50/55 shadow-xs hover:shadow-lg dark:bg-stone-900/60 dark:border-stone-800 transition-all duration-300 cursor-pointer scale-98 hover:scale-100"
              >
                <div>
                  {/* Blog Header Image */}
                  <div className="relative h-48 overflow-hidden bg-stone-300">
                    <img
                      src={post.imageUrl}
                      alt={post.title}
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute left-4 top-4 z-10 rounded-full bg-[#A22D22]/90 px-3 py-1 text-[9px] uppercase font-bold text-white dark:bg-amber-500 dark:text-stone-950">
                      {lang === 'en' ? post.category : post.categoryBn}
                    </span>
                  </div>

                  {/* Body Copy */}
                  <div className="p-6 space-y-3">
                    <div className="flex items-center gap-4 text-[10px] font-bold text-stone-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-stone-400" />
                        <span>{post.publishDate}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3 text-stone-400" />
                        <span>{post.author}</span>
                      </span>
                    </div>

                    <h3 className="font-heading text-lg font-bold leading-snug text-stone-900 group-hover:text-[#A22D22] dark:text-stone-50 dark:group-hover:text-amber-400 transition-colors line-clamp-2">
                      {lang === 'en' ? post.title : post.titleBn}
                    </h3>

                    <p className="text-xs text-stone-700 dark:text-stone-300 leading-relaxed line-clamp-3">
                      {lang === 'en' ? post.excerpt : post.excerptBn}
                    </p>
                  </div>
                </div>

                {/* Footer Controls & Actions */}
                <div className="p-6 pt-0 border-t border-stone-200/50 dark:border-stone-800/50 flex items-center justify-between mt-4">
                  
                  {/* Like Button */}
                  <button
                    onClick={(e) => handleLike(post.id, e)}
                    className="flex items-center gap-1 text-xs text-stone-500 hover:text-red-500 dark:text-stone-400 dark:hover:text-red-400 transition-colors group/like"
                  >
                    <Heart className="h-4 w-4 shrink-0 transition-transform group-hover/like:scale-120 group-hover/like:text-rose-500 text-rose-500 fill-rose-500/20" />
                    <span className="font-semibold text-[11px]">{post.likes}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {isAdmin && (
                      <>
                        <button
                          onClick={(e) => handleInitEdit(post, e)}
                          className="p-1 rounded text-stone-500 hover:bg-stone-200 dark:hover:bg-stone-800 hover:text-stone-950 dark:hover:text-white"
                          title="Edit Post"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={(e) => handleDeletePost(post.id, e)}
                          className="p-1 rounded text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                          title="Delete Post"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </>
                    )}
                    <span className="text-xs font-bold text-[#A22D22] dark:text-amber-400 flex items-center gap-1 group-hover:translate-x-1.5 transition-transform">
                      <span>{d.readMore}</span>
                      <Eye className="h-3.5 w-3.5" />
                    </span>
                  </div>

                </div>
              </article>
            ))}
          </div>
        )}

      </div>

      {/* Full-bleed Blog Article Reader Modal */}
      {readingPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 animate-in fade-in duration-300" id="blog-reader-modal">
          <div className="relative w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-stone-900 border border-orange-100 dark:border-stone-800 transition-colors max-h-[90vh] overflow-y-auto">
            
            {/* Post Banner */}
            <div className="relative h-64 sm:h-80 w-full">
              <div className="absolute inset-0 bg-gradient-to-t from-stone-900 to-transparent z-10" />
              <img
                src={readingPost.imageUrl}
                alt={readingPost.title}
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => setReadingPost(null)}
                className="absolute right-4 top-4 z-30 rounded-full bg-black/60 p-2 text-white hover:bg-black/95 backdrop-blur-md"
                aria-label="Close reader"
              >
                <X className="h-5 w-5" />
              </button>
              
              <div className="absolute bottom-6 left-6 sm:left-8 z-20 text-white max-w-2xl">
                <span className="rounded-full bg-amber-500 text-stone-950 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-widest inline-block mb-2">
                  {lang === 'en' ? readingPost.category : readingPost.categoryBn}
                </span>
                <h3 className="font-heading text-2xl sm:text-3xl font-black tracking-tight drop-shadow-md">
                  {lang === 'en' ? readingPost.title : readingPost.titleBn}
                </h3>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 sm:p-8 space-y-6">
              
              {/* Meta Data Row */}
              <div className="flex flex-wrap items-center gap-6 border-b border-stone-100 pb-4 dark:border-stone-800 text-xs font-semibold text-stone-500 dark:text-stone-400">
                <div className="flex items-center gap-1.5">
                  <User className="h-4.5 w-4.5 text-[#A22D22] dark:text-amber-400" />
                  <span>{readingPost.author}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4.5 w-4.5 text-[#A22D22] dark:text-amber-400" />
                  <span>{readingPost.publishDate}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4.5 w-4.5 text-[#A22D22] dark:text-amber-400" />
                  <span>5 mins read</span>
                </div>
              </div>

              {/* Text Area */}
              <div className="prose prose-stone dark:prose-invert max-w-none text-stone-800 dark:text-stone-200">
                {/* Format content nicely dividing paragraphs by double empty lines */}
                {(lang === 'en' ? readingPost.content : readingPost.contentBn).split('\n\n').map((para, i) => {
                  if (para.startsWith('**') || para.startsWith('*')) {
                    // Check for lists or headings
                    return (
                      <p key={i} className="text-sm leading-relaxed font-bold text-stone-900 dark:text-white mt-4">
                        {para.replace(/\*\*/g, '')}
                      </p>
                    );
                  }
                  return (
                    <p key={i} className="text-sm leading-relaxed mb-4">
                      {para}
                    </p>
                  );
                })}
              </div>

              {/* Close Button Footer */}
              <div className="pt-6 border-t border-stone-200/50 dark:border-stone-800 flex items-center justify-between">
                <button
                  onClick={(e) => {
                    handleLike(readingPost.id, e);
                    setReadingPost(prev => prev ? { ...prev, likes: prev.likes + 1 } : null);
                  }}
                  className="flex items-center gap-1.5 text-xs font-bold text-rose-600 border border-rose-200/40 px-3.5 py-1.5 rounded-lg hover:bg-rose-50"
                >
                  <Heart className="h-4 w-4 fill-rose-500 text-rose-500" />
                  <span>{lang === 'en' ? 'Support story' : 'গল্পটি পছন্দ করুন'} ({readingPost.likes})</span>
                </button>

                <button
                  onClick={() => setReadingPost(null)}
                  className="rounded-lg bg-stone-950 text-white px-5 py-2 text-xs font-bold hover:bg-stone-800 dark:bg-stone-800 dark:text-stone-200"
                >
                  {lang === 'en' ? 'Close Article' : 'বন্ধ করুন'}
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
}
