/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, X, Globe, Sun, Moon, Shield, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY } from '../data';

interface NavbarProps {
  lang: Language;
  setLang: (lang: Language) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
}

export default function Navbar({
  lang,
  setLang,
  darkMode,
  setDarkMode,
  isAdmin,
  setIsAdmin,
  activeSection,
  setActiveSection
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');

  const d = DICTIONARY[lang];

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'kailas123' || adminPassword.toLowerCase() === 'admin' || adminPassword === '') {
      setIsAdmin(true);
      setShowAdminModal(false);
      setAdminError('');
      setAdminPassword('');
    } else {
      setAdminError('Incorrect credential. Hint: Leave empty or enter "kailas123" to authorize.');
    }
  };

  const navItems = [
    { id: 'home', label: d.home },
    { id: 'about', label: d.about },
    { id: 'destinations', label: d.destinations },
    { id: 'ferry', label: d.timetable },
    { id: 'blogs', label: d.blogs },
    { id: 'owner', label: d.owner },
    { id: 'contact', label: d.contact }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-orange-100 bg-[#FCF9F5]/90 backdrop-blur-md dark:border-stone-800 dark:bg-stone-950/90 transition-colors duration-300">
      <div className="mx-auto flex max-w-7xl h-20 items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo & Slogan */}
        <div 
          onClick={() => setActiveSection('home')} 
          className="flex cursor-pointer flex-col justify-center select-none"
          id="nav-logo"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-[#A22D22]/90 to-[#DF961A]/90 text-white shadow-md">
              <span className="font-extrabold text-xl tracking-tight">B</span>
            </div>
            <div>
              <h1 className="font-sans text-xl font-bold tracking-tight text-stone-900 dark:text-neutral-50">
                {d.title}
              </h1>
              <p className="hidden xs:block text-[10px] font-medium tracking-wider text-rose-800 dark:text-amber-400 uppercase">
                {d.slogan}
              </p>
            </div>
          </div>
        </div>

        {/* Desktop Navigation Link Tabs */}
        <nav className="hidden lg:flex items-center space-x-1" id="nav-desktop-links">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => setActiveSection(item.id)}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-all duration-300 ${
                activeSection === item.id
                  ? 'bg-rose-900/10 text-[#A22D22] dark:bg-amber-400/10 dark:text-amber-400 font-semibold'
                  : 'text-stone-700 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-300 dark:hover:bg-stone-800 dark:hover:text-amber-400'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Toolbar Triggers (Bilingual, DarkMode, AdminMode, MobileMenu) */}
        <div className="flex items-center space-x-2" id="nav-actions">
          
          {/* Quick Language Toggle */}
          <button
            onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
            id="lang-toggle-btn"
            className="flex items-center gap-1.5 rounded-lg border border-orange-100 bg-[#FCF9F5] px-2.5 py-1.5 text-xs font-semibold text-[#A22D22] hover:bg-orange-50 dark:border-stone-800 dark:bg-stone-900 dark:text-amber-400 dark:hover:bg-stone-800 transition-all duration-300"
            title="Switch Language / ভাষা পরিবর্তন করুন"
          >
            <Globe className="h-4 w-4" />
            <span>{lang === 'en' ? 'বাংলা' : 'EN'}</span>
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            id="darkmode-toggle-btn"
            className="rounded-lg p-2 text-stone-600 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-yellow-400 transition-all duration-300"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="h-4.5 w-4.5" /> : <Moon className="h-4.5 w-4.5" />}
          </button>

          {/* Admin Command Toggle Portal */}
          {isAdmin ? (
            <button
              onClick={() => setIsAdmin(false)}
              id="admin-active-pills"
              className="hidden sm:flex items-center gap-1.5 rounded-lg bg-emerald-600/10 border border-emerald-500/20 px-3 py-1.5 text-xs font-semibold text-emerald-600 dark:bg-emerald-400/10 dark:text-emerald-400"
              title="Admin Mode Enabled. Click to Logout."
            >
              <Shield className="h-3.5 w-3.5 animate-pulse" />
              <span>{lang === 'en' ? 'Kailas (Admin)' : 'কৈলাস (অ্যাডমিন)'}</span>
            </button>
          ) : (
            <button
              onClick={() => setShowAdminModal(true)}
              id="admin-login-button"
              className="hidden sm:flex items-center gap-1 text-xs font-medium text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-200 border border-dashed border-stone-300 dark:border-stone-700 px-2.5 py-1.5 rounded-lg"
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Admin</span>
            </button>
          )}

          {/* Mobile responsive toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="mobile-menu-trigger"
            className="flex items-center justify-center rounded-lg p-2 text-stone-700 hover:bg-stone-100 dark:text-stone-300 dark:hover:bg-stone-800 lg:hidden transition-colors"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden animate-in fade-in slide-in-from-top duration-300 bg-[#FCF9F5] border-t border-orange-50 dark:bg-stone-950 dark:border-stone-900" id="nav-mobile-menu">
          <div className="space-y-1.5 px-4 py-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-left px-4 py-2.5 rounded-lg text-base font-medium transition-colors ${
                  activeSection === item.id
                    ? 'bg-rose-900/10 text-[#A22D22] dark:bg-amber-400/10 dark:text-amber-400 font-bold'
                    : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="border-t border-stone-200 dark:border-stone-800 my-2 pt-2">
              {isAdmin ? (
                <button
                  onClick={() => {
                    setIsAdmin(false);
                    setMobileMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 px-4 py-2.5 text-rose-600 font-medium"
                >
                  <Shield className="h-4 w-4" />
                  <span>Logout Admin Mode</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowAdminModal(true);
                    setMobileMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 px-4 py-2.5 text-stone-600 dark:text-stone-400"
                >
                  <Shield className="h-4 w-4" />
                  <span>Admin Sign-In</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Admin Sign-In Authorization Modal */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 backdrop-blur-xs p-4 animate-in fade-in" id="admin-auth-modal">
          <div className="w-full max-w-md rounded-2xl bg-[#FCF9F5] p-6 shadow-2xl dark:bg-stone-900 border border-[#A22D22]/10 transition-colors">
            
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-[#A22D22] dark:text-amber-400">
                <Shield className="h-5 w-5" />
                <h3 className="font-heading text-lg font-bold">Admin Portal Authorization</h3>
              </div>
              <button 
                onClick={() => {
                  setShowAdminModal(false);
                  setAdminError('');
                }}
                className="rounded-full p-1 text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600 dark:text-stone-300 mb-4 bg-amber-500/10 border border-amber-500/10 rounded-lg p-3">
              <Sparkles className="h-3.5 w-3.5 inline mr-1 text-amber-600" />
              Hello <strong>Kailas Halder</strong>! Admin Mode unlocks complete editable controls over daily news bulletins, blog updates, and Ganganagar & Kakdwip ferry timetables.
            </p>

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5">
                  Admin Passkey
                </label>
                <input
                  type="password"
                  placeholder="Enter administrator passkey..."
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full rounded-lg border border-orange-200 bg-white px-3.5 py-2 text-sm text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-[#A22D22]/40 dark:border-stone-700 dark:bg-stone-800 dark:text-white"
                  autoFocus
                />
                <span className="text-[10px] text-stone-500 mt-1 block">
                  Hint: Leave empty or write <strong>kailas123</strong> to login instantly!
                </span>
                {adminError && (
                  <p className="mt-2 text-xs font-medium text-rose-600 dark:text-rose-400">
                    {adminError}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAdminModal(false);
                    setAdminError('');
                  }}
                  className="px-4 py-2 text-xs font-semibold text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200"
                >
                  {d.cancel}
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-[#A22D22] px-4 py-2 text-xs font-bold text-white hover:bg-[#832018] dark:bg-amber-500 dark:text-stone-950 dark:hover:bg-amber-400 transition-colors"
                >
                  Authorize Mode
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </header>
  );
}
