/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Send, MapPin, Phone, Mail, Globe, Facebook, Instagram, Youtube, MessageCircle, CheckCircle2 } from 'lucide-react';
import { Language, ContactMessage } from '../types';
import { DICTIONARY } from '../data';

interface ContactProps {
  lang: Language;
  onNewMessage: (msg: ContactMessage) => void;
}

export default function Contact({ lang, onNewMessage }: ContactProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const d = DICTIONARY[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !message) {
      alert(lang === 'en' ? 'Please fill in all standard contact form fields.' : 'দয়া করে ফরমের সবকটি ঘর পূরণ করুন।');
      return;
    }

    setSubmitting(true);

    const newMsg: ContactMessage = {
      id: 'msg-' + Date.now(),
      name,
      email,
      phone,
      message,
      date: new Date().toLocaleString(lang === 'en' ? 'en-US' : 'bn-BD')
    };

    // Simulate short network delay
    setTimeout(() => {
      onNewMessage(newMsg);
      setSuccess(true);
      setSubmitting(false);

      // Clean fields
      setName('');
      setEmail('');
      setPhone('');
      setMessage('');

      // Auto-flash success confirmation off after 5 seconds
      setTimeout(() => {
        setSuccess(false);
      }, 5500);
    }, 1200);
  };

  return (
    <section id="contact-section" className="py-20 bg-white dark:bg-stone-950 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block">
            {lang === 'en' ? 'Get in Touch' : 'আজই আমাদের সাথে যোগাযোগ স্থাপন করুন'}
          </span>
          <h2 className="font-heading text-3xl font-extrabold text-[#2D251F] dark:text-neutral-50 sm:text-4xl">
            {lang === 'en' ? 'Send Your Inquiries & Tourism Questions' : 'আপনার জিজ্ঞাসা এবং বার্তা পাঠান'}
          </h2>
          <div className="h-1 w-20 bg-[#A22D22] dark:bg-[#DF961A] mx-auto rounded-full" />
        </div>

        {/* Double-Column Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch" id="contact-inner-grid">
          
          {/* Symmetrical Left Form Column */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div className="rounded-2xl border border-orange-50 bg-[#FCF9F5] p-6 sm:p-8 dark:border-stone-900 dark:bg-stone-900/40 shadow-md">
              <h3 className="font-heading text-xl font-bold text-stone-900 dark:text-white mb-6">
                {lang === 'en' ? 'Contact Inquiry Desk' : 'জিজ্ঞাসা কেন্দ্র'}
              </h3>

              {success && (
                <div className="mb-6 flex items-center gap-3 rounded-lg bg-emerald-50 border border-emerald-200 p-4 dark:bg-emerald-950/20 dark:border-emerald-800/40 animate-in fade-in" id="contact-success-indicator">
                  <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span className="text-sm font-semibold text-emerald-800 dark:text-emerald-300">
                    {d.submitSuccess}
                  </span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">{d.nameLabel}</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-orange-200/50 bg-white px-3.5 py-2.5 text-sm text-stone-900 focus:outline-hidden focus:ring-1 focus:ring-[#A22D22]/40 dark:border-stone-800 dark:bg-stone-950 dark:text-white"
                    placeholder="Enter your full name..."
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">{d.emailLabel}</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-lg border border-orange-200/50 bg-white px-3.5 py-2.5 text-sm text-stone-900 focus:outline-hidden focus:ring-1 focus:ring-[#A22D22]/40 dark:border-stone-800 dark:bg-stone-950 dark:text-white"
                      placeholder="name@domain.com"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">{d.phoneLabel}</label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full rounded-lg border border-orange-200/50 bg-white px-3.5 py-2.5 text-sm text-stone-900 focus:outline-hidden focus:ring-1 focus:ring-[#A22D22]/40 dark:border-stone-800 dark:bg-stone-950 dark:text-white"
                      placeholder="+91-XXXXX-XXXXX"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">{d.messageLabel}</label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full rounded-lg border border-orange-200/50 bg-white px-3.5 py-2.5 text-sm text-stone-900 focus:outline-hidden focus:ring-1 focus:ring-[#A22D22]/40 dark:border-stone-800 dark:bg-stone-950 dark:text-white"
                    placeholder={lang === 'en' ? 'How can we help you plan your Kakdwip / Bengal travel?' : 'গঙ্গাসাগর বা পর্যটন সেবা সংক্রান্ত আপনার প্রশ্নটি লিখুন...'}
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-[#A22D22] py-3 text-sm font-bold text-white shadow-md hover:bg-[#832018] dark:bg-amber-500 dark:text-stone-950 dark:hover:bg-amber-400 transition-colors duration-300 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                    <span>{submitting ? d.submitting : d.send}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Symmetrical Right Column: Social Channels & Iframe Google Maps */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            
            {/* Social channels card list */}
            <div className="rounded-2xl border border-orange-50 bg-[#FCF9F5] p-6 dark:border-stone-900 dark:bg-stone-900/40 shadow-md">
              <h4 className="font-heading text-sm font-bold text-stone-400 uppercase tracking-widest mb-4">
                Official Channels & Social Networks
              </h4>
              <div className="grid grid-cols-2 gap-4">
                
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-white hover:bg-rose-50 border border-orange-50/20 dark:bg-stone-950 dark:hover:bg-stone-900 dark:border-stone-900/50 transition-colors"
                >
                  <div className="p-2 rounded-lg bg-blue-600/10 text-blue-600 shrink-0">
                    <Facebook className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold block uppercase">Facebook</span>
                    <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">Beautiful Bengal</span>
                  </div>
                </a>

                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-white hover:bg-rose-50 border border-orange-50/20 dark:bg-stone-950 dark:hover:bg-stone-900 dark:border-stone-900/50 transition-colors"
                >
                  <div className="p-2 rounded-lg bg-pink-600/10 text-pink-600 shrink-0">
                    <Instagram className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold block uppercase">Instagram</span>
                    <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">@BeautifulBengal</span>
                  </div>
                </a>

                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-white hover:bg-rose-50 border border-orange-50/20 dark:bg-stone-950 dark:hover:bg-stone-900 dark:border-stone-900/50 transition-colors"
                >
                  <div className="p-2 rounded-lg bg-red-600/10 text-red-600 shrink-0">
                    <Youtube className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold block uppercase">YouTube</span>
                    <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">Beautiful Bengal TV</span>
                  </div>
                </a>

                <a
                  href="https://wa.me/917557041947"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 p-3 rounded-xl bg-white hover:bg-[#25D366]/10 border border-orange-50/20 dark:bg-stone-950 dark:hover:bg-[#25D366]/5 dark:border-stone-900/50 transition-colors"
                >
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600 shrink-0">
                    <MessageCircle className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-stone-400 font-bold block uppercase">WhatsApp</span>
                    <span className="text-xs font-semibold text-stone-700 dark:text-stone-300">Chat with Kailas</span>
                  </div>
                </a>

              </div>
            </div>

            {/* Google map iframe embed representing Kakdwip location */}
            <div className="relative rounded-2xl overflow-hidden border border-orange-100 dark:border-stone-850 h-64 sm:h-auto min-h-[220px] flex-1 shadow-md">
              <iframe
                title="Google Maps Embed Location - Kakdwip, West Bengal"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59247.962635313936!2d88.15814529999999!3d21.8769399!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a02fa48e91f09c9%3A0xe5ed8090bd551adb!2sKakdwip%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
