/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BookOpen, Sparkles, Leaf, Trees, Landmark, Waves, Music, Heart, Palmtree, Soup } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY } from '../data';

interface AboutProps {
  lang: Language;
}

export default function About({ lang }: AboutProps) {
  const d = DICTIONARY[lang];

  const specialties = [
    {
      icon: BookOpen,
      title: lang === 'en' ? 'Rich Bengali Culture' : 'সমৃদ্ধ বাঙালি সংস্কৃতি',
      desc: lang === 'en' ? 'Home to Nobel laureate Rabindranath Tagore, rich poetry, theater, and classical literature traditions.' : 'কবিগুরু রবীন্দ্রনাথ ঠাকুরের জন্মভূমি, নাট্যচর্চা এবং ধ্রুপদী সাহিত্য ঐতিহ্যে ভরপুর অনন্য সংস্কৃতি।'
    },
    {
      icon: Sparkles,
      title: lang === 'en' ? 'Durga Puja Festival' : 'ঐতিহাসিক দুর্গাপূজা উৎসব',
      desc: lang === 'en' ? 'A UNESCO Intangible Cultural Heritage extravaganza featuring massive street art installations and massive joy.' : 'ইউনেস্কোর হেরিটেজ তকমাপ্রাপ্ত মহোৎসব, যেখানে বিশাল নান্দনিক আলোর মণ্ডপ ও রাজকীয় সার্বজনীন আনন্দের মেলবন্ধন ঘটে।'
    },
    {
      icon: Soup,
      title: lang === 'en' ? 'Famous Bengali Sweets' : 'জগৎবিখ্যাত বাঙালি মিষ্টি',
      desc: lang === 'en' ? 'Succulent Rosogolla, soft Sandesh, and legendary Nolen Gur that sweeten every human heart.' : 'সুস্বাদু রসগোল্লা, তুলতুলে নরম সন্দেশ এবং খেজুর রস থেকে তৈরি জিভে জল আনা নলেন গুড়ের মিষ্টত্ব।'
    },
    {
      icon: Leaf,
      title: lang === 'en' ? 'Tea Gardens of Darjeeling' : 'দার্জিলিংয়ের চায়ের বাগান',
      desc: lang === 'en' ? 'World renowned champagne of teas cultivated carefully along snowy mist-covered mountain valleys.' : 'বিশ্বসেরা সুগন্ধযুক্ত কুয়াশাচ্ছন্ন পাহাড়ি ঢালে উৎপাদিত উৎকৃষ্ট মানের দার্জিলিংয়ের ব্ল্যাক টি বা লিকার চা।'
    },
    {
      icon: Trees,
      title: lang === 'en' ? 'Sundarbans Mangrove' : 'সুন্দরবন ম্যানগ্রোভ বন',
      desc: lang === 'en' ? 'Largest mangrove eco-reserve globally and native habitat of the fierce Royal Bengal Tiger.' : 'পৃথিবীর বৃহত্তম ম্যানগ্রোভ বনাঞ্চল এবং রাজকীয় ভাবগম্ভীর রয়্যাল বেঙ্গল টাইগারের শান্তিময় বিচরণস্থল।'
    },
    {
      icon: Landmark,
      title: lang === 'en' ? 'Historical Sites' : 'ঐতিহাসিক রাজকীয় স্থাপত্য',
      desc: lang === 'en' ? 'Terracotta temples of Bishnupur, Hazarduari Palaces of Murshidabad, and monuments of Kolkata.' : 'বিষ্ণুপুরের পোড়ামাটির মন্দির, মুর্শিদাবাদের হাজারদুয়ারী প্যালেস এবং কলকাতার ভিক্টোরিয়া হেরিটেজ।'
    },
    {
      icon: Palmtree,
      title: lang === 'en' ? 'Pristine Sea Beaches' : 'মনোরম বঙ্গোপসাগর সৈকত',
      desc: lang === 'en' ? 'Vast tropical shores of Digha, Mandarmani, and Bakkhali bordering the active Bay of Bengal.' : 'বঙ্গোপسাগরের উত্তাল তরঙ্গে ঘেরা দিঘা, মন্দারমণি এবং বকখালি অঞ্চলের দীর্ঘ চমৎকার দীর্ঘ বালুকাময় সমুদ্রসৈকত।'
    },
    {
      icon: Music,
      title: lang === 'en' ? 'Traditional Music & Art' : 'লোকগান এবং ঐতিহ্যবাহী শিল্প',
      desc: lang === 'en' ? 'Soulful Baul spiritual songs, Bhatiyali boatman tunes, and spectacular folk dances.' : 'লালন শাহ ও সাঁইজির বাউল গীতি, শান্ত ভাটিয়ালী গান এবং ঐতিহ্যবাহী ছৌ লোকনৃত্যের আদি প্রকাশ।'
    },
    {
      icon: Heart,
      title: lang === 'en' ? 'Warm Hospitality' : 'উষ্ণ ও আন্তরিক আতিথেয়তা',
      desc: lang === 'en' ? 'An open-hearted welcoming philosophy: "Athithi Devo Bhava," making all tourists feel at home.' : 'হৃদয় উজাড় করা আতিথেয়তা, যেখানে আগত প্রতিটি পর্যটককে পরম সমাদরে আপন করে নেওয়া হয়।'
    },
    {
      icon: Soup,
      title: lang === 'en' ? 'Delicious Cuisine' : 'জিভে জল আনা বাঙালি রান্না',
      desc: lang === 'en' ? 'The legendary Maachh-Bhaat (fish-rice), traditional Shukto, and mustard flavored gravies.' : "ঐতিহ্যবাহী মাছে-ভাতে বাঙালি আহার, মুখরোচক শুক্তো এবং খাঁটি সরষে ইলিশ ও রকমারি রান্নার দারুণ আয়োজন।"
    }
  ];

  return (
    <section id="about-section" className="py-20 bg-[#FBF8F3] dark:bg-stone-900 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* About Main Header Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block">
              {lang === 'en' ? 'Gateway to the East' : 'পূর্ব ভারতের প্রবেশদ্বার'}
            </span>
            <h2 className="font-heading text-3xl font-extrabold text-stone-900 dark:text-neutral-50 sm:text-4xl">
              {lang === 'en' ? 'About West Bengal' : 'পশ্চিমবঙ্গ সম্পর্কে কিছু কথা'}
            </h2>
            <div className="h-1 w-20 bg-[#A22D22] dark:bg-[#DF961A] rounded-full" />
            
            <p className="text-stone-700 dark:text-stone-300 leading-relaxed text-base">
              {lang === 'en' ? (
                "West Bengal is one of India's most culturally rich states, famous for its literature, festivals, tea gardens, mangrove forests, beaches, heritage sites, art, music, and delicious sweets."
              ) : (
                "পশ্চিমবঙ্গ ভারতের অন্যতম সংস্কৃতি সমৃদ্ধ রাজ্য হিসেবে গর্বিত, যা তার সাহিত্য, মেলা ও উৎসব, চা বাগান, ম্যানগ্রোভ অরণ্য, সমুদ্রসৈকত, প্রাচীন স্থাপত্যকলা, সঙ্গীত এবং সুস্বাদু মিষ্টির জন্য বিশ্বখ্যাত।"
              )}
            </p>

            <p className="text-stone-700 dark:text-stone-300 leading-relaxed text-base">
              {lang === 'en' ? (
                "West Bengal offers a unique, priceless combination of snow-capped mountains (the Himalayas in the North) and vast sea bays (the mangrove-rich Sundarbans and beach resorts in the South), flowing dynamic rivers, and historical architectures all nestled inside a single beautiful state."
              ) : (
                "পশ্চিমবঙ্গ ভারতের একমাত্র রাজ্য যা একই সীমানার মধ্যে উত্তরে তুষারাবৃত হিমালয় পর্বতমালা থেকে শুরু করে দক্ষণে বঙ্গোপসাগর উপকূলবর্তী ম্যানগ্রোভ অরণ্য সুন্দরবন, বিশাল উর্বর সমভূমি নদীমাতৃক ভূখণ্ড এবং দীর্ঘ বালুকাময় সমুদ্রসৈকতের এক অপূর্ব মেলবন্ধন অফার করে।"
              )}
            </p>

            {/* Geographical Blessed Bullet Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {[
                { en: 'The Himalayas in the north', bn: 'উত্তরে অপরূপ হিমালয় পর্বতমালা' },
                { en: 'The Sundarbans mangrove forest', bn: 'দক্ষিণে সুন্দরবন ম্যানগ্রোভ বন' },
                { en: 'Beautiful sea beaches in south', bn: 'মনোরম বঙ্গোপসাগরীয় সমুদ্র সৈকত' },
                { en: 'Darjeeling Tea gardens', bn: 'দার্জিলিংয়ের সবুজ চা বাগিচা' },
                { en: 'Historical monuments', bn: 'ঐতিহাসিক রাজকীয় স্মৃতিসৌধসমূহ' },
                { en: 'Durga Puja UNESCO carnival', bn: 'বিশ্বখ্যাত দুর্গোৎসব কার্নিভাল' },
                { en: 'Rich Bengali Culture & Sweets', bn: 'উন্নত বাঙালি সংস্কৃতি ও ছানার মিষ্টি' },
                { en: 'Traditional arts and handicrafts', bn: 'ঐতিহ্যবাহী পোড়ামাটি ও ডোকরা হস্তশিল্প' }
              ].map((point, index) => (
                <div key={index} className="flex items-center gap-2.5">
                  <div className="h-2 w-2 rounded-full bg-[#A22D22] dark:bg-[#DF961A]" />
                  <span className="text-sm font-medium text-stone-800 dark:text-stone-200">
                    {lang === 'en' ? point.en : point.bn}
                  </span>
                </div>
              ))}
            </div>

          </div>

          {/* Graphical Map/Handicraft Aesthetic Grid */}
          <div className="lg:col-span-5 relative">
            <div className="absolute inset-0 bg-gradient-to-br from-[#A22D22]/10 to-[#DF961A]/10 rounded-2xl blur-xl" />
            <div className="relative rounded-2xl border border-orange-100 bg-white/70 p-6 dark:border-stone-800 dark:bg-stone-950/75 shadow-xl">
              <img 
                src="https://images.unsplash.com/photo-1598902108854-10e335adac99?q=80&w=800" 
                alt="Bengal Heritage Craft"
                className="rounded-lg object-cover w-full h-64 mb-4 shadow-inner"
                referrerPolicy="no-referrer"
              />
              <div className="border-t border-orange-100 dark:border-stone-800 pt-4 text-center">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-widest block">
                  {lang === 'en' ? 'Lal Paar Saree & Sweets Vibe' : 'লাল পাড় শাড়ি ও লোকসংস্কৃতি'}
                </span>
                <p className="text-sm text-stone-600 dark:text-stone-400 mt-1">
                  {lang === 'en' ? 'West Bengal offers a unique combination of mountains, forests, rivers, and sea within a single state.' : 'সমগ্র রাজ্যে পাহাড়, নদী, সমভূমি এবং সমুদ্রের এক স্বর্গীয় যুগলবন্দী দেখা যায়।'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Attractions Icons Section */}
        <div className="border-t border-orange-100 dark:border-stone-800 pt-16">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="font-heading text-2xl font-bold text-stone-950 dark:text-neutral-100">
              {d.whyBengalSpecial}
            </h3>
            <p className="text-sm text-stone-600 dark:text-stone-400 mt-2">
              {lang === 'en' ? 'Explore the distinct elements that compose Bengal\'s deep historical charisma' : 'বাঙালি হৃদয়ের নানা রঙ এবং পর্যটন কেন্দ্রগুলোর মূল আকর্ষণগুলো এক নজরে দেখুন'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {specialties.map((item, id) => {
              const IconComp = item.icon;
              return (
                <div
                  key={id}
                  id={`specialty-card-${id}`}
                  className="group flex flex-col justify-between rounded-xl bg-white p-5 border border-orange-50 shadow-xs hover:shadow-md hover:border-[#DF961A]/30 dark:bg-stone-950 dark:border-stone-800/80 transition-all duration-300"
                >
                  <div className="space-y-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 dark:bg-stone-900 text-[#A22D22] dark:text-[#DF961A] group-hover:scale-110 transition-transform">
                      <IconComp className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-stone-900 dark:text-neutral-50 group-hover:text-[#A22D22] dark:group-hover:text-amber-300 transition-colors">
                        {item.title}
                      </h4>
                      <p className="text-xs text-stone-600 dark:text-stone-400 mt-1.5 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
