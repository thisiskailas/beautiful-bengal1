/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Shield, MapPin, Mail, Award, Target, Landmark, Heart } from 'lucide-react';
import { Language } from '../types';
import { DICTIONARY } from '../data';

interface AboutOwnerProps {
  lang: Language;
}

export default function AboutOwner({ lang }: AboutOwnerProps) {
  const d = DICTIONARY[lang];

  return (
    <section id="owner-section" className="py-20 bg-[#FBF8F3] dark:bg-stone-900 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Symmetrical Left Column: Website Owner Info Card */}
          <div className="lg:col-span-5" id="owner-profile-container">
            <div className="relative rounded-3xl border border-orange-100 bg-white p-8 dark:border-stone-800 dark:bg-stone-950 shadow-xl overflow-hidden">
              {/* Traditional background decorations */}
              <div className="absolute top-0 right-0 h-24 w-24 bg-rose-900/10 dark:bg-amber-400/5 rounded-full blur-xl" />
              <div className="absolute -bottom-8 -left-8 h-32 w-32 bg-[#DF961A]/10 rounded-full blur-xl" />

              <div className="relative flex flex-col items-center text-center space-y-5">
                
                {/* Profile Photo Placeholder - Styled with Golden Marigold Rings */}
                <div className="relative">
                  <div className="absolute inset-0 rounded-full border-4 border-dashed border-[#DF961A]/40 animate-spin duration-30000" />
                  <div className="m-2 h-36 w-36 overflow-hidden rounded-full border-4 border-white bg-[#FCF9F5] shadow-md dark:border-stone-900">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop" 
                      alt="Kailas Halder"
                      className="h-full w-full object-cover rounded-full grayscale hover:grayscale-0 transition-all duration-500"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  {/* Founder badge icon */}
                  <span className="absolute bottom-2 right-2 rounded-full bg-[#A22D22] p-2 text-white shadow-md dark:bg-amber-500 dark:text-stone-950">
                    <Award className="h-4 w-4" />
                  </span>
                </div>

                <div>
                  <h3 className="font-heading text-2xl font-extrabold text-stone-900 dark:text-white">
                    {d.ownerName}
                  </h3>
                  <p className="text-xs font-bold text-[#A22D22] dark:text-amber-400 uppercase tracking-wider mt-1.5 matches-owner-role">
                    {d.ownerRole}
                  </p>
                </div>

                <div className="h-0.5 w-1/3 bg-orange-100 dark:bg-stone-800" />

                {/* Symmetrical address list metadata */}
                <div className="w-full text-left space-y-3.5 text-xs text-stone-700 dark:text-stone-300">
                  <div className="flex items-start gap-3">
                    <div className="p-1.5 rounded-lg bg-orange-50 text-[#A22D22] dark:bg-stone-900 dark:text-amber-400 shrink-0">
                      <MapPin className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-semibold text-stone-900 dark:text-white">
                        {lang === 'en' ? 'Administrative Address' : 'কার্যালয়ের ঠিকানা'}
                      </p>
                      <p className="text-stone-600 dark:text-stone-400 mt-0.5 leading-relaxed font-semibold">
                        Kakdwip, South 24 Parganas, West Bengal, India – 743347
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="p-1.5 rounded-lg bg-orange-50 text-[#A22D22] dark:bg-stone-900 dark:text-amber-400 shrink-0">
                      <Mail className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-semibold text-stone-900 dark:text-white">Email Address</p>
                      <p className="text-stone-600 dark:text-stone-400 mt-0.5 font-mono select-all">
                        iamkailas@duck.com
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="p-1.5 rounded-lg bg-orange-50 text-[#A22D22] dark:bg-stone-900 dark:text-amber-400 shrink-0">
                      <Shield className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-semibold text-stone-900 dark:text-white">Authority</p>
                      <p className="text-stone-600 dark:text-stone-400 mt-0.5">
                        {lang === 'en' ? 'Official Beautiful Bengal Portal Host' : 'অফিশিয়াল বিউটিফুল বেঙ্গল পোর্টাল হোস্ট'}
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Symmetrical Right Column: Beautiful Banner Mission statement */}
          <div className="lg:col-span-7 space-y-8" id="our-mission-container">
            <div className="space-y-4">
              <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block flex items-center gap-1.5">
                <Target className="h-4 w-4" />
                <span>{d.mission}</span>
              </span>
              <h2 className="font-heading text-3xl font-extrabold text-stone-900 dark:text-neutral-50 sm:text-4xl">
                {lang === 'en' ? 'Spreading Bengal’s Warmth Worldwide' : 'বাংলার মুখ বিশ্বমঞ্চে আলোকিত করা'}
              </h2>
              <div className="h-1 w-20 bg-[#A22D22] dark:bg-[#DF961A] rounded-full" />
            </div>

            {/* Large citation testimonial block */}
            <blockquote className="relative rounded-2xl border-l-4 border-[#A22D22] bg-white/70 p-6 sm:p-8 dark:border-[#DF961A] dark:bg-stone-950/70 shadow-md">
              <span className="font-serif text-5xl text-[#A22D22]/20 dark:text-[#DF961A]/20 absolute top-2 left-4 select-none">“</span>
              <p className="relative font-serif text-base italic leading-relaxed text-stone-800 dark:text-stone-200">
                {d.missionText}
              </p>
              <cite className="mt-4 block font-heading text-xs font-bold uppercase tracking-wider text-[#A22D22] dark:text-amber-400 not-italic">
                — {d.ownerName}, {lang === 'en' ? 'Founder & Administrator' : 'প্রতিষ্ঠাতা ও পরিচালক'}
              </cite>
            </blockquote>

            {/* Quality Statement Bullet Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/40 p-4 rounded-xl border border-orange-100 dark:bg-[#1C1814] dark:border-stone-800">
                <h4 className="font-bold text-sm text-[#A22D22] dark:text-amber-400 flex items-center gap-1.5">
                  <Heart className="h-4 w-4" />
                  <span>{lang === 'en' ? 'Authentic Integration' : 'সত্যিকারের সহযোগিতা'}</span>
                </h4>
                <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
                  {lang === 'en' ? 'Providing real vessel data, ferry timetables, local updates, and tourist advice for visitors traveling through Kakdwip.' : 'কাকদ্বীপ ও গঙ্গাসাগরে যাতায়াতকারী পর্যটক ও স্থানীয়দের সুবিধার্থে ভেসেলের সঠিক ও সত্য তথ্য উপস্থাপন করা।'}
                </p>
              </div>

              <div className="bg-white/40 p-4 rounded-xl border border-orange-100 dark:bg-[#1C1814] dark:border-stone-800">
                <h4 className="font-bold text-sm text-[#A22D22] dark:text-amber-400 flex items-center gap-1.5">
                  <Landmark className="h-4 w-4" />
                  <span>{lang === 'en' ? 'Preserving Heritage' : 'ঐতিহ্য সংরক্ষণ'}</span>
                </h4>
                <p className="text-xs text-stone-600 dark:text-stone-400 mt-2 leading-relaxed">
                  {lang === 'en' ? 'Showcasing the historic terracotas, local arts, music, delicious recipes, and sweet-making artisans of Rural Bengal.' : 'বাংলার মৃৎশিল্প, টেরাকোটা সৌধ, বাউল কৃষ্টি ও ঐতিহ্যময় কারিগরদের অমূল্য অবদানকে বিশ্বের নিকট পরিচিত করা।'}
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
