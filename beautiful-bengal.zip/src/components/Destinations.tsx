/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, MapPin, Sparkles, X, ChevronRight, Check } from 'lucide-react';
import { Language, TouristDestination } from '../types';
import { INITIAL_DESTINATIONS, DICTIONARY } from '../data';

interface DestinationsProps {
  lang: Language;
}

export default function Destinations({ lang }: DestinationsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeModal, setActiveModal] = useState<TouristDestination | null>(null);

  const d = DICTIONARY[lang];

  const categories = ['All', 'Hills', 'Forest', 'Beaches', 'Heritage', 'Metropolitan'];

  const filteredDestinations = INITIAL_DESTINATIONS.filter((dest) => {
    const matchesSearch =
      dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dest.nameBn.includes(searchQuery) ||
      dest.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dest.descriptionBn.includes(searchQuery);

    const matchesCategory = selectedCategory === 'All' || dest.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <section id="destinations-section" className="py-20 bg-white dark:bg-stone-950 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Title & Subtitle */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gap-4">
          <div>
            <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block">
              {lang === 'en' ? 'Plan your itinerary' : 'আপনার পছন্দসই গন্তব্য বেছে নিন'}
            </span>
            <h2 className="font-heading text-3xl font-extrabold text-stone-900 dark:text-neutral-50 sm:text-4xl mt-1">
              {lang === 'en' ? 'Popular Tourist Destinations' : 'জনপ্রিয় পর্যটন কেন্দ্রসমূহ'}
            </h2>
          </div>

          {/* Search Input Bar */}
          <div className="relative w-full max-w-xs md:max-w-md">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-stone-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              placeholder={d.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-orange-100 bg-[#FCF9F5] pl-10 pr-4 py-2.5 text-sm font-medium text-stone-900 placeholder-stone-500 shadow-inner focus:border-[#A22D22] focus:outline-hidden dark:border-stone-800 dark:bg-stone-900 dark:text-stone-100"
            />
          </div>
        </div>

        {/* Categories Tab Selection Row */}
        <div className="flex flex-wrap items-center gap-2 mb-8" id="dest-category-row">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-full px-4 py-2 text-xs font-semibold transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-[#A22D22] text-white shadow-md dark:bg-amber-500 dark:text-stone-950'
                  : 'bg-[#FCF9F5] text-stone-700 hover:bg-stone-100 border border-orange-50 dark:bg-stone-900 dark:text-stone-300 dark:border-stone-800 dark:hover:bg-stone-800'
              }`}
            >
              {cat === 'All' ? d.categoryAll : cat}
            </button>
          ))}
        </div>

        {/* Destinations Result Grid */}
        {filteredDestinations.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-stone-200 dark:border-stone-800 rounded-2xl bg-orange-50/5">
            <MapPin className="h-10 w-10 mx-auto text-stone-300 mb-3 animate-pulse" />
            <p className="text-sm font-semibold text-stone-600 dark:text-stone-400">
              {lang === 'en' ? 'No matching destinations found. Try searching another place.' : 'কোন মিল খুঁজে পাওয়া যায়নি। দয়া করে অন্য জায়গার নাম লিখুন।'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="destinations-grid">
            {filteredDestinations.map((dest, idx) => (
              <div
                key={dest.id}
                id={`destination-card-${dest.id}`}
                className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-stone-100 bg-[#FCF9F5] dark:border-stone-900 dark:bg-stone-900/60 shadow-xs hover:shadow-lg transition-all duration-500 scale-98 hover:scale-100"
              >
                {/* Destination Image Showcase with Hover Zoom */}
                <div className="relative h-64 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/15 z-10" />
                  <img
                    src={dest.image}
                    alt={dest.name}
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  {/* Category Pill Tag */}
                  <span className="absolute right-4 top-4 z-20 rounded-full bg-black/60 px-3 py-1 text-[10px] uppercase font-bold text-amber-400 tracking-wider backdrop-blur-md">
                    {dest.category}
                  </span>
                  {/* Title over image bottom */}
                  <div className="absolute bottom-4 left-4 z-20 text-white">
                    <h3 className="font-heading text-2xl font-black tracking-tight flex items-center gap-1.5 drop-shadow-md">
                      <MapPin className="h-4 w-4 text-rose-500 fill-rose-500" />
                      <span>{lang === 'en' ? dest.name : dest.nameBn}</span>
                    </h3>
                  </div>
                </div>

                {/* Info Text Area */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div className="space-y-3">
                    <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed line-clamp-3">
                      {lang === 'en' ? dest.description : dest.descriptionBn}
                    </p>
                    {/* Tiny bullet list */}
                    <div className="space-y-1 pt-1">
                      {(lang === 'en' ? dest.highlights.slice(0, 2) : dest.highlightsBn.slice(0, 2)).map((hl, i) => (
                        <div key={i} className="flex items-center gap-1.5 text-stone-500">
                          <Check className="h-3 w-3 text-emerald-500 shrink-0" />
                          <span className="text-[10px] font-semibold dark:text-stone-400">{hl}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-stone-200/50 dark:border-stone-800 flex justify-end">
                    <button
                      onClick={() => setActiveModal(dest)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-[#A22D22] dark:text-amber-400 group-hover:underline transition-all"
                    >
                      <span>{lang === 'en' ? 'Explore Details' : 'বিস্তারিত দেখুন'}</span>
                      <ChevronRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>

      {/* Destination Detailed Information Modal Dialogue */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 animate-in fade-in duration-300" id="destination-modal">
          <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-stone-900 border border-orange-100 dark:border-stone-800 transition-colors max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header Banner Image */}
            <div className="relative h-64 sm:h-80 w-full">
              <div className="absolute inset-0 bg-gradient-to-t from-stone-900 to-transparent z-10" />
              <img
                src={activeModal.image}
                alt={activeModal.name}
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
              />
              {/* Close Button */}
              <button
                onClick={() => setActiveModal(null)}
                className="absolute right-4 top-4 z-30 rounded-full bg-black/60 p-2 text-white hover:bg-black/95 backdrop-blur-md"
                aria-label="Close modal"
              >
                <X className="h-5 w-5" />
              </button>
              {/* Title Overlay */}
              <div className="absolute bottom-6 left-6 sm:left-8 z-20 text-white">
                <span className="rounded-full bg-amber-500 text-stone-950 px-2.5 py-0.5 text-[10px] font-extrabold uppercase tracking-widest inline-block mb-2">
                  {activeModal.category}
                </span>
                <h3 className="font-heading text-3xl font-black tracking-tight drop-shadow-md">
                  {lang === 'en' ? activeModal.name : activeModal.nameBn}
                </h3>
              </div>
            </div>

            {/* Modal Explanatory Content Body */}
            <div className="p-6 sm:p-8 space-y-6">
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest">
                  {lang === 'en' ? 'Overview' : 'সংক্ষিপ্ত বিবরণ'}
                </h4>
                <p className="text-sm text-stone-700 dark:text-stone-300 leading-relaxed">
                  {lang === 'en' ? activeModal.description : activeModal.descriptionBn}
                </p>
              </div>

              {/* Highlights Bullet List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest flex items-center gap-1">
                  <Sparkles className="h-4.5 w-4.5 text-amber-500" />
                  <span>{lang === 'en' ? 'Key Tourist Attractions & Highlights' : 'প্রধান দর্শনীয় স্পট ও আকর্ষণের তালক'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {(lang === 'en' ? activeModal.highlights : activeModal.highlightsBn).map((hl, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2.5 rounded-lg bg-orange-50/40 p-3 text-sm text-stone-800 border border-orange-100/30 dark:bg-stone-800/50 dark:text-stone-200 dark:border-stone-800"
                    >
                      <div className="flex h-5 w-5 items-center justify-center rounded-full bg-[#A22D22]/10 text-[#A22D22] dark:bg-amber-400/10 dark:text-amber-400">
                        <Check className="h-3 w-3" />
                      </div>
                      <span className="font-medium text-xs text-stone-700 dark:text-stone-300">{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-stone-200/50 dark:border-stone-800 flex justify-end">
                <button
                  onClick={() => setActiveModal(null)}
                  className="rounded-lg bg-stone-900 text-white px-5 py-2.5 text-sm font-bold hover:bg-stone-800 dark:bg-stone-800 dark:text-stone-200 dark:hover:bg-stone-700 transition-colors"
                >
                  {lang === 'en' ? 'Done' : 'ঠিক আছে'}
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
}
