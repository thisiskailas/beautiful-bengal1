/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, MapPin, Globe, Sparkles, FileCode, Check, Copy, CheckCircle2 } from 'lucide-react';
import { Language, BlogPost } from '../types';
import { DICTIONARY } from '../data';

interface SeoSitemapProps {
  lang: Language;
  blogs: BlogPost[];
}

export default function SeoSitemap({ lang, blogs }: SeoSitemapProps) {
  const [copiedTab, setCopiedTab] = useState<'xml' | 'json' | null>(null);
  const [selectedSubTab, setSelectedSubTab] = useState<'sitemap' | 'schema'>('sitemap');

  const d = DICTIONARY[lang];

  // Base domain
  const domain = 'https://beautifulbengal.org';

  // Generate XML sitemap
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${domain}/</loc>
    <lastmod>2026-06-02</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${domain}/#about</loc>
    <lastmod>2026-06-02</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/#destinations</loc>
    <lastmod>2026-06-02</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/#schedules</loc>
    <lastmod>2026-06-02</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${domain}/#bulletins</loc>
    <lastmod>2026-06-02</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  ${blogs.map(blog => `  <url>
    <loc>${domain}/blogs/${blog.id}</loc>
    <lastmod>${blog.publishDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>`).join('\n')}
</urlset>`;

  // Generate JSON-LD Google Structural Data Schema
  const ldJsonSchema = {
    "@context": "https://schema.org",
    "@type": "TouristInformationCenter",
    "name": "Beautiful Bengal - Tourism, Culture & Timetable Portal",
    "alternateName": "বিউটিফুল বেঙ্গল",
    "description": "West Bengal - The Sweetest Part Of India. Official West Bengal, Kakdwip navigation ferry schedules & culture center.",
    "url": domain,
    "logo": `${domain}/logo.png`,
    "founder": {
      "@type": "Person",
      "name": "Kailas Halder",
      "jobTitle": "Founder & Administrator"
    },
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Kakdwip Subdivision",
      "addressLocality": "South 24 Parganas",
      "addressRegion": "West Bengal",
      "postalCode": "743347",
      "addressCountry": "IN"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "contactType": "Administrator",
      "email": "iamkailas@duck.com"
    },
    "hasMap": "https://maps.google.com/?q=Kakdwip,South+24+Parganas,West+Bengal,India"
  };

  const handleCopy = (text: string, type: 'xml' | 'json') => {
    navigator.clipboard.writeText(text);
    setCopiedTab(type);
    setTimeout(() => {
      setCopiedTab(null);
    }, 2000);
  };

  return (
    <section id="seo-section" className="py-20 bg-stone-50 dark:bg-stone-900/40 border-t border-stone-200/40 dark:border-stone-850">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-[#A22D22] dark:text-[#DF961A] tracking-widest uppercase block flex items-center gap-1">
              <FileCode className="h-4 w-4 animate-pulse" />
              <span>{d.seoTab}</span>
            </span>
            <h2 className="font-heading text-3xl font-extrabold text-stone-950 dark:text-stone-100 mt-1">
              {lang === 'en' ? 'SEO-Optimized Crawling & Metadata' : 'সার্চ ইঞ্জিন ক্রলিং মেটাডাটা'}
            </h2>
            <p className="text-xs text-stone-600 dark:text-stone-400 mt-2">
              {d.sitemapDesc}
            </p>
          </div>

          <div className="flex gap-2 bg-stone-200/50 p-1 rounded-xl dark:bg-stone-950">
            <button
              onClick={() => setSelectedSubTab('sitemap')}
              className={`px-4 py-2 text-xs font-black rounded-lg transition-all ${
                selectedSubTab === 'sitemap'
                  ? 'bg-white text-[#A22D22] shadow-xs dark:bg-stone-900 dark:text-amber-400'
                  : 'text-stone-600 dark:text-stone-450'
              }`}
            >
              XML Sitemap
            </button>
            <button
              onClick={() => setSelectedSubTab('schema')}
              className={`px-4 py-2 text-xs font-black rounded-lg transition-all ${
                selectedSubTab === 'schema'
                  ? 'bg-white text-[#A22D22] shadow-xs dark:bg-stone-900 dark:text-amber-400'
                  : 'text-stone-600 dark:text-stone-450'
              }`}
            >
              JSON-LD Schema
            </button>
          </div>
        </div>

        {/* Outer Code Terminal Display Container */}
        <div className="overflow-hidden rounded-2xl border border-stone-200 dark:border-stone-800 bg-stone-900 text-stone-300 font-mono text-xs shadow-2xl">
          
          <div className="flex items-center justify-between bg-stone-950 border-b border-stone-800 p-4">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-red-500" />
              <div className="h-3 w-3 rounded-full bg-yellow-500" />
              <div className="h-3 w-3 rounded-full bg-green-500" />
              <span className="text-[10px] text-stone-500 uppercase font-bold tracking-widest pl-2">
                {selectedSubTab === 'sitemap' ? 'sitemap.xml (Autogenerated)' : 'structured-data-schema.json (JSON-LD)'}
              </span>
            </div>

            {selectedSubTab === 'sitemap' ? (
              <button
                onClick={() => handleCopy(sitemapXml, 'xml')}
                className="flex items-center gap-1 px-3 py-1 bg-stone-800 hover:bg-stone-700 text-[10px] text-white rounded-lg transition"
              >
                {copiedTab === 'xml' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedTab === 'xml' ? 'Copied XML!' : 'Copy Code'}</span>
              </button>
            ) : (
              <button
                onClick={() => handleCopy(JSON.stringify(ldJsonSchema, null, 2), 'json')}
                className="flex items-center gap-1 px-3 py-1 bg-stone-800 hover:bg-stone-700 text-[10px] text-white rounded-lg transition"
              >
                {copiedTab === 'json' ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedTab === 'json' ? 'Copied JSON!' : 'Copy Code'}</span>
              </button>
            )}
          </div>

          <div className="p-6 max-h-[290px] overflow-y-auto bg-[#171412] text-amber-500/80 leading-relaxed text-[11px]">
            {selectedSubTab === 'sitemap' ? (
              <pre className="whitespace-pre overflow-x-auto text-orange-200">{sitemapXml}</pre>
            ) : (
              <pre className="whitespace-pre overflow-x-auto text-emerald-300">{JSON.stringify(ldJsonSchema, null, 2)}</pre>
            )}
          </div>

          <div className="bg-stone-950 p-3.5 border-t border-stone-850 flex items-center justify-between text-[11px] text-stone-500">
            <span>{d.analyticsSim}</span>
            <span className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping inline-block" />
              <span>Crawl index criteria: sitemap, microdata active</span>
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}
