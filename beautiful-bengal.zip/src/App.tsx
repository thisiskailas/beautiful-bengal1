/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Ship, Newspaper, Compass, AlertCircle, Heart, Users, Mail, ShieldAlert, Sparkles, Smile, ArrowUp } from 'lucide-react';
import { Language, BlogPost, VesselSchedule, ContactMessage } from './types';
import { INITIAL_BLOGS, INITIAL_SCHEDULES, DICTIONARY } from './data';

// import components
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Destinations from './components/Destinations';
import FerrySchedules from './components/FerrySchedules';
import UpdateCenter from './components/UpdateCenter';
import AboutOwner from './components/AboutOwner';
import Contact from './components/Contact';
import SeoSitemap from './components/SeoSitemap';

export default function App() {
  // Lang state
  const [lang, setLang] = useState<Language>('en');

  // Dark mode state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('bb_dark_mode');
    return saved === 'true';
  });

  // Admin authorization mode
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Active navigation section
  const [activeSection, setActiveSection] = useState<string>('home');

  // Core CMS state loaded from LocalStorage or defaults
  const [schedules, setSchedules] = useState<VesselSchedule[]>(() => {
    const saved = localStorage.getItem('bb_schedules');
    if (saved) return JSON.parse(saved);
    return INITIAL_SCHEDULES;
  });

  const [blogs, setBlogs] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem('bb_blogs');
    if (saved) return JSON.parse(saved);
    return INITIAL_BLOGS;
  });

  const [messages, setMessages] = useState<ContactMessage[]>(() => {
    const saved = localStorage.getItem('bb_messages');
    if (saved) return JSON.parse(saved);
    return [];
  });

  // Scroll to top arrow show
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    localStorage.setItem('bb_schedules', JSON.stringify(schedules));
  }, [schedules]);

  useEffect(() => {
    localStorage.setItem('bb_blogs', JSON.stringify(blogs));
  }, [blogs]);

  useEffect(() => {
    localStorage.setItem('bb_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('bb_dark_mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const d = DICTIONARY[lang];

  // Inbox handler for user inquiries
  const handleNewMessage = (msg: ContactMessage) => {
    setMessages(prev => [msg, ...prev]);
  };

  const handleDeleteMessage = (id: string) => {
    setMessages(prev => prev.filter(m => m.id !== id));
  };

  return (
    <div className={`min-h-screen bg-[#FCF9F5] text-stone-850 dark:bg-stone-950 dark:text-stone-100 font-sans transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      
      {/* 1. Header Navigation Bar Component */}
      <Navbar
        lang={lang}
        setLang={setLang}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        isAdmin={isAdmin}
        setIsAdmin={setIsAdmin}
        activeSection={activeSection}
        setActiveSection={(sec) => {
          setActiveSection(sec);
          // Auto scroll to target section container
          const targetEl = document.getElementById(`${sec}-anchor`);
          if (targetEl) {
            targetEl.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

      {/* Anchor point target for Navbar */}
      <div id="home-anchor" className="scroll-mt-20" />

      {/* 2. Hero Image Rotator Carousel Section */}
      <Hero
        lang={lang}
        onExplore={() => {
          setActiveSection('destinations');
          document.getElementById('destinations-anchor')?.scrollIntoView({ behavior: 'smooth' });
        }}
        onUpdates={() => {
          setActiveSection('blogs');
          document.getElementById('blogs-anchor')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* Main Single Page Responsive Frame View */}
      <main className="relative">
        
        {/* Floating Quick Action Nav indicator for simple UI boundaries */}
        <div className="bg-[#DF961A]/10 border-y border-amber-500/10 dark:bg-stone-900/40">
          <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6 lg:px-8 flex flex-wrap items-center justify-between gap-4 text-xs font-semibold text-stone-700 dark:text-stone-300">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-[#A22D22] animate-ping" />
              <span>{lang === 'en' ? 'Quick Information Desk' : 'ত্বরিত তথ্য বার্তা’'} : </span>
              <span className="text-[#A22D22] dark:text-amber-400">
                {lang === 'en' ? ' Sagar Ferry operating under regular low-tide conditions.' : ' সাগরদ্বীপ ভেসেল নিয়মিত সময়সূচী অনুযায়ী সচল।'}
              </span>
            </div>

            {/* Simulated Live counter stats */}
            <div className="flex items-center gap-4">
              <span>{lang === 'en' ? 'Live visitors: 1,482' : 'লাইভ পরিদর্শক: ১,৪৮২'}</span>
              <span>•</span>
              <span>{lang === 'en' ? 'Sagar Timetable Sync: Active' : 'সময়সূচি সিঙ্ক: সচল'}</span>
            </div>
          </div>
        </div>

        {/* 3. Global Inbox/Message Console Display (For Kailas under Admin Mode!) */}
        {isAdmin && (
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-8" id="admin-inbox-dashboard">
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.03] p-6 dark:border-amber-400/10">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-emerald-500/10">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-amber-400">
                  <ShieldAlert className="h-5 w-5 animate-bounce" />
                  <div>
                    <h3 className="font-heading text-lg font-bold">Admin Inquiry Inbox Console</h3>
                    <p className="text-[10px] text-stone-500 dark:text-stone-400">
                      Messages left by visitors on your contact section. Saved to browser Local Storage.
                    </p>
                  </div>
                </div>
                <span className="rounded-full bg-emerald-600 px-2.5 py-0.5 text-xs text-white font-bold">
                  {messages.length} inquiries
                </span>
              </div>

              {messages.length === 0 ? (
                <div className="text-center py-6 text-stone-500 text-xs italic">
                  <Smile className="h-8 w-8 text-stone-300 mx-auto mb-2" />
                  No guest messages received yet in this session. Send one via the contact form to verify!
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[300px] overflow-y-auto pr-2">
                  {messages.map((msg) => (
                    <div key={msg.id} className="bg-white p-4 rounded-xl border border-stone-200 dark:bg-stone-950 dark:border-stone-850 text-xs space-y-2相对 shadow-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-bold text-stone-900 dark:text-white text-sm">{msg.name}</p>
                          <p className="text-[10px] text-stone-400">{msg.date}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          className="text-stone-400 hover:text-red-500 text-[10px] font-bold border border-stone-100 p-1 hover:bg-stone-50 rounded"
                          title="Clear Message"
                        >
                          Clear
                        </button>
                      </div>
                      <p className="text-[10px] font-mono text-[#A22D22] dark:text-amber-400 font-semibold select-all">
                        {msg.email} | {msg.phone}
                      </p>
                      <p className="text-stone-700 dark:text-stone-300 leading-relaxed italic border-t border-stone-100 pt-2 font-serif">
                        "{msg.message}"
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* 4. About Bengal Section */}
        <div id="about-anchor" className="scroll-mt-20">
          <About lang={lang} />
        </div>

        {/* 5. Popular Tourist Destinations Component */}
        <div id="destinations-anchor" className="scroll-mt-20">
          <Destinations lang={lang} />
        </div>

        {/* 6. Vessel Schedules Component (Fully Editable in admin mode!) */}
        <div id="ferry-anchor" className="scroll-mt-20">
          <FerrySchedules
            lang={lang}
            isAdmin={isAdmin}
            schedules={schedules}
            setSchedules={setSchedules}
          />
        </div>

        {/* 7. Blog and News Center Component */}
        <div id="blogs-anchor" className="scroll-mt-20">
          <UpdateCenter
            lang={lang}
            isAdmin={isAdmin}
            blogs={blogs}
            setBlogs={setBlogs}
          />
        </div>

        {/* 10. Owner Profile Section */}
        <div id="owner-anchor" className="scroll-mt-20">
          <AboutOwner lang={lang} />
        </div>

        {/* 11. Contact Form, Google Maps & Social Icons Section */}
        <div id="contact-anchor" className="scroll-mt-20">
          <Contact
            lang={lang}
            onNewMessage={handleNewMessage}
          />
        </div>

        {/* 12. Automated Sitemap & JSON-LD SEO Diagnostics */}
        <SeoSitemap
          lang={lang}
          blogs={blogs}
        />

      </main>

      {/* Elegant Symmetrical Cultural Footer */}
      <footer className="bg-stone-950 text-stone-400 border-t border-stone-900 transition-colors duration-300">
        
        {/* Colorful top border representing West Bengal landscape */}
        <div className="h-1.5 bg-gradient-to-r from-[#A22D22] via-[#DF961A] to-amber-500" />

        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start mb-8 text-xs">
            
            {/* Left Col: Core Slogan and Owner credit */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-700 text-white font-extrabold text-sm">
                  <span>B</span>
                </div>
                <h3 className="font-heading text-base font-extrabold text-white">
                  {d.title}
                </h3>
              </div>
              <p className="text-stone-400 font-serif leading-relaxed italic max-w-md">
                "{d.slogan}. Discover the mystical tea mountains, the delta mangroves, the royal tigers, historical red-brick potteries, and the sweet embrace of authentic Bengali hosting."
              </p>
              <p className="text-[10px] text-stone-500 font-mono">
                Port 3000 Ingress Routing Engine Active • React 19 Client Persistence Core • Created for Kailas Halder, Kakdwip, South 24 Parganas.
              </p>
            </div>

            {/* Symmetrical Mid Col: Fast section jump links */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="font-heading text-xs font-extrabold uppercase tracking-widest text-[#DF961A]">
                {lang === 'en' ? 'Quick Portal Sectors' : 'দ্রুত লিঙ্কসমূহ'}
              </h4>
              <ul className="space-y-2">
                {[
                  { id: 'about', label: d.about },
                  { id: 'destinations', label: d.destinations },
                  { id: 'ferry', label: d.timetable },
                  { id: 'blogs', label: d.blogs },
                  { id: 'owner', label: d.owner }
                ].map(l => (
                  <li key={l.id}>
                    <button
                      onClick={() => {
                        setActiveSection(l.id);
                        document.getElementById(`${l.id}-anchor`)?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="hover:text-amber-400 tracking-wide transition-colors font-semibold"
                    >
                      {l.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Symmetrical Right Col: Contact direct list */}
            <div className="md:col-span-4 space-y-3">
              <h4 className="font-heading text-xs font-extrabold uppercase tracking-widest text-[#DF961A]">
                {lang === 'en' ? 'Administrator Helpdesk' : 'প্রশাসক হেল্পডেস্ক'}
              </h4>
              <div className="space-y-2.5 text-stone-400 leading-relaxed font-semibold">
                <p className="flex items-center gap-2">
                  <span className="text-[#A22D22] dark:text-amber-400">Owner:</span> 
                  <span>{d.ownerName}</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <span className="text-[#A22D22] dark:text-amber-400">Sector:</span> 
                  <span>Kakdwip, South 24 Parganas, WB, India - 743347</span>
                </p>
                <p className="flex items-center gap-1.5 font-mono select-all text-[11px]">
                  <span>Email:</span>
                  <span>iamkailas@duck.com</span>
                </p>
              </div>
            </div>

          </div>

          <div className="border-t border-stone-900 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-stone-500 gap-4">
            <p>
              © {new Date().getFullYear()} Beautiful Bengal. All Rights Reserved. Conceptualized, packaged, and managed securely inside Indian Cultural Bengal.
            </p>
            <div className="flex gap-4">
              <span>{lang === 'en' ? 'UNESCO Intangible Heritages Spotter' : 'ইউনেস্কো ঐতিহ্য সংরক্ষক'}</span>
              <span>•</span>
              <button 
                onClick={() => setIsAdmin(!isAdmin)}
                className="hover:text-amber-400 transition-colors"
                id="footer-admin-toggle"
              >
                {isAdmin ? (lang === 'en' ? 'Lock Admin Portal' : 'লক অ্যাডমিন') : (lang === 'en' ? 'Admin Portal' : 'অ্যাডমিন পোর্টাল')}
              </button>
            </div>
          </div>

        </div>

      </footer>

      {/* Floating WhatsApp Direct Chat trigger */}
      <a
        href="https://wa.me/917557041947"
        target="_blank"
        rel="noopener noreferrer"
        id="whatsapp-floating-btn"
        className="fixed bottom-6 left-6 z-40 flex items-center justify-center rounded-full bg-[#25D366] p-3.5 text-white shadow-2xl hover:bg-[#128C7E] scale-100 hover:scale-110 active:scale-95 transition-all duration-300"
        title={lang === 'en' ? 'Chat with Kailas on WhatsApp' : 'কৈলাসের সাথে হোয়াটসঅ্যাপে চ্যাট করুন'}
      >
        <svg
          className="h-7 w-7 fill-current shrink-0"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
        </svg>
      </a>

      {/* Floating Scroll back to top arrow trigger */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          id="scroll-to-top-btn"
          className="fixed bottom-6 right-6 z-40 rounded-full bg-[#A22D22] p-3 text-white shadow-xl hover:bg-[#832018] dark:bg-[#DF961A] dark:text-stone-950 dark:hover:bg-amber-400 transition-all duration-300"
          aria-label="Scroll back layout to top"
        >
          <ArrowUp className="h-4.5 w-4.5" />
        </button>
      )}

    </div>
  );
}
