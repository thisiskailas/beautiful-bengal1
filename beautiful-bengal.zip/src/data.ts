/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TouristDestination, BlogPost, VesselSchedule } from './types';

export const INITIAL_DESTINATIONS: TouristDestination[] = [
  {
    id: 'darjeeling',
    name: 'Darjeeling',
    nameBn: 'দার্জিলিং',
    image: 'https://images.unsplash.com/photo-1555899434-94d1368aa7af?q=80&w=1200&auto=format&fit=crop',
    description: 'Known as the "Queen of the Hills", Darjeeling is famous for its lush tea gardens, panoramic Himalayan views of Mt. Kanchenjunga, world-famous UNESCO Toy Train, and pleasant misty climate.',
    descriptionBn: 'পাহাড়ের রানী নামে পরিচিত দার্জিলিং তার সতেজ চা বাগান, কাঞ্চনজঙ্ঘার মনোরম দৃশ্য, ইউনেস্কো হেরিটেজ টয় ট্রেন এবং চমৎকার মনোরম আবহাওয়ার জন্য বিখ্যাত।',
    highlights: ['Tiger Hill Sunrise', 'Batasia Loop', 'UNESCO Toy Train Ride', 'Darjeeling Tea tasting'],
    highlightsBn: ['টাইগার হিল সূর্যোদয়', 'বাতাসিয়া লুপ', 'টয় ট্রেন যাত্রা', 'দার্জিলিংয়ের চা আস্বাদন'],
    category: 'Hills'
  },
  {
    id: 'sundarbans',
    name: 'Sundarbans',
    nameBn: 'সুন্দরবন',
    image: 'https://images.unsplash.com/photo-1616160975936-7c050217be8a?q=80&w=1200&auto=format&fit=crop',
    description: 'The Sundarbans is the world\'s largest mangrove forest and home to the majestic Royal Bengal Tiger. It is a UNESCO World Heritage Site with deep waterways, dense canopy, and unique coastal wildlife.',
    descriptionBn: 'সুন্দরবন বিশ্বের বৃহত্তম ম্যানগ্রোভ অরণ্য এবং রাজকীয় রয়্যাল বেঙ্গল টাইগারের বাসস্থান। এটি একটি ইউনেস্কো বিশ্ব ঐতিহ্যবাহী স্থান যা অসংখ্য নদীনালা এবং সমৃদ্ধ জীববৈচিত্র্যে ঘেরা।',
    highlights: ['Sajnekhali Watch Tower', 'Royal Bengal Tiger spotting', 'Mangrove Boat Safari', 'Dobanki Canopy Walk'],
    highlightsBn: ['সজনেখালি ওয়াচ টাওয়ার', 'রয়্যাল বেঙ্গল টাইগার দর্শন', 'ম্যানগ্রোভ বোট সাফারি', 'দোবাঁকী ক্যানোপি ওয়াক'],
    category: 'Forest'
  },
  {
    id: 'kolkata',
    name: 'Kolkata',
    nameBn: 'কলকাতা',
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?q=80&w=1200&auto=format&fit=crop',
    description: 'The cultural capital of India, Kolkata is landmarked by imperial-era architecture, historical tramways, iconic landmark Howrah Bridge, rich literature, art galleries, and mouth-watering sweets.',
    descriptionBn: 'ভারতের সাংস্কৃতিক রাজধানী কলকাতা তার ঐতিহাসিক স্থাপত্য, ঐতিহ্যবাহী ট্রামওয়ে, ঐতিহ্যমণ্ডিত হাওড়া ব্রিজ, সমৃদ্ধ সাহিত্য, আর্ট গ্যালারি এবং সুস্বাদু মিষ্টির জন্য বিশ্বখ্যাত।',
    highlights: ['Victoria Memorial', 'Dakshineswar Kali Temple', 'Howrah Bridge', 'Street Food Tour at Park Street'],
    highlightsBn: ['ভিক্টোরিয়া মেমোরিয়াল', 'দক্ষিণেশ্বর কালী মন্দির', 'হাওড়া ব্রিজ', 'পার্ক স্ট্রিটের বিখ্যাত স্ট্রিট ফুড'],
    category: 'Metropolitan'
  },
  {
    id: 'digha',
    name: 'Digha',
    nameBn: 'দিঘা',
    image: 'https://images.unsplash.com/photo-1545562083-a600704fa487?q=80&w=1200&auto=format&fit=crop',
    description: 'West Bengal\'s most popular seaside resort town, famous for its flat hard beaches, dynamic sea waves, dramatic sunrises, cascading casuarina forests, and delicious seafood options.',
    descriptionBn: 'পশ্চিমবঙ্গের সবচেয়ে জনপ্রিয় সমুদ্রসৈকত শহর, যা সমতল শান্ত সৈকত, মনোরম সূর্যোদয় ও সূর্যাস্ত, ঝাউবন এবং সুস্বাদু সামুদ্রিক খাবারের জন্য অত্যন্ত সুপরিচিত।',
    highlights: ['New Digha Beach', 'Udaypur Beach', 'Marine Aquarium', 'Amrabati Park boating'],
    highlightsBn: ['নিউ দিঘা সৈকত', 'উদয়পুর সৈকত', 'সামুদ্রিক অ্যাকোয়ারিয়াম', 'আমরাবতী পার্ক বোটিং'],
    category: 'Beaches'
  },
  {
    id: 'bishnupur',
    name: 'Bishnupur',
    nameBn: 'বিষ্ণুপুর',
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=1200&auto=format&fit=crop',
    description: 'Renowned for its iconic terracotta temples built by Malla Kings during the 17th century, Bishnupur is a treasure trove of heritage, traditional Baluchari sarees, and metal handicrafts like Dokra.',
    descriptionBn: '১৭ শতকে মল্ল রাজাদের দ্বারা নির্মিত বিখ্যাত টেরাকোটা বা পোড়ামাটির মন্দিরের জন্য পরিচিত বিষ্ণুপুর ঐতিহ্যবাহী বালুচরি শাড়ি এবং ডোকরা ধাতু হস্তশিল্পের জন্য বিখ্যাত।',
    highlights: ['Rasmancha', 'Madan Mohan Temple', 'Baluchari Weaving Centers', ' terracotta artifacts'],
    highlightsBn: ['রাস মঞ্চ', 'মদন মোহন মন্দির', 'বালুচরি তাঁত বয়ন কেন্দ্র', 'টেরাকোটা শিল্পসামগ্রী'],
    category: 'Heritage'
  }
];

export const INITIAL_BLOGS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'A Tourist Guide to Sagar Island: Pilgrimage and Serenity',
    titleBn: 'সাগর দ্বীপ ভ্রমণ নির্দেশিকা: তীর্থযাত্রা ও প্রশান্তি',
    excerpt: 'Discover the secrets of Sagar Island, a sacred destination at the confluence of the Ganges and the Bay of Bengal.',
    excerptBn: 'গঙ্গা ও বঙ্গোপসাগরের সঙ্গমস্থলে অবস্থিত পবিত্র গঙ্গা সাগর দ্বীপের অপরূপ সৌন্দর্য এবং তীর্থযাত্রার বিবরণ।',
    content: `Sagar Island, located in the Kakdwip subdivision of South 24 Parganas, is a place of religious significance and sublime natural beauty. Popularly referred to as Gangasagar, it is here that the sacred Holy Ganges flows directly into the Bay of Bengal.

Every year during Makar Sankranti (mid-January), millions of pilgrims from across India gather here to take a holy dip at the confluence and offer prayers at the Kapil Muni Temple. However, Sagar Island is also an exceptional offbeat destination during the rest of the year. 

**How to reach:**
1. Travel from Kolkata to Kakdwip (Harwood Point or Lot No. 8) by road or train.
2. Board a ferry crossing the Muriganga river to Kachuberia.
3. Take local buses or private vehicles from Kachuberia to the Sagar Island beach.

Enjoy quiet sand dunes, a red crab beach, majestic sunsets, and supreme spiritual quietude. Discover the true vibe of Bengal!`,
    contentBn: `সাগর দ্বীপ, দক্ষিণ ২৪ পরগনার কাকদ্বীপ মহকুমার অধীনে অবস্থিত একটি অত্যন্ত পবিত্র এবং প্রাকৃতিক সৌন্দর্যে ভরপুর স্থান। এটি গঙ্গাসাগর নামে অধিক পরিচিত, যেখানে পবিত্র গঙ্গা নদী সরাসরি বঙ্গোপসাগরে মিলিত হয়েছে।

প্রতি বছর মকর সংক্রান্তির সময় (জানুয়ারির মাঝামাঝি), ভারতের বিভিন্ন প্রান্ত থেকে লক্ষ লক্ষ পুণ্যার্থী এই সঙ্গমস্থলে পুণ্যস্নান করতে এবং কপিল মুনি মন্দিরে পূজা দিতে আসেন। তবে বছরের অন্যান্য সময়েও এটি সুন্দর ও নিরিবিলি সৈকত ভ্রমণের জন্য চমৎকার স্থান।

**যাতায়াত ব্যবস্থা:**
১. কলকাতা থেকে সড়ক বা রেলপথে কাকদ্বীপ (হারউড পয়েন্ট বা লট নং ৮) পৌঁছান।
২. মুড়িগঙ্গা নদী পার হওয়ার জন্য ফেরি বা ভেসেলে চড়ে কচুবেড়িয়া পৌঁছান।
৩. কচুবেড়িয়া থেকে নামমাত্র ভাড়ায় বাস বা প্রাইভেট গাড়িতে গঙ্গাসাগর সমুদ্রসৈকতে চলে যান।

পরিষ্কার বালিয়াড়ি, লাল কাঁকড়ার সৈকত, চমৎকার সূর্যাস্ত এবং আধ্যাত্মিক প্রশান্তির অপরূপ মিলনে হারিয়ে যান। বাংলার রূপ অনুভব করুন!`,
    category: 'Travel',
    categoryBn: 'ভ্রমণ নির্দেশিকা',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=600',
    publishDate: '2026-05-28',
    author: 'Kailas Halder',
    likes: 42
  },
  {
    id: 'blog-2',
    title: 'Discovering Terracotta: The Royal Legacy of Bishnupur',
    titleBn: 'টেরাকোটার টানে: বিষ্ণুপুরের রাজকীয় ঐতিহ্য',
    excerpt: 'Step back in time and learn about the magnificent burnt-clay temples constructed by the Malla dynastic rulers.',
    excerptBn: 'মল্ল রাজাদের দ্বারা নির্মিত পোড়ামাটির ঐতিহাসিক মন্দিরের রাজকীয় ইতিহাস এবং তাদের নির্মাণশৈলী জানুন।',
    content: `Bishnupur in Bankura district is synonymous with exquisite terracotta brick temples and traditional Baluchari sarees. Between the 16th and 19th centuries, the local Malla kings constructed temples using locally sourced alluvial clay bricks, since building-stone was highly scarce in Bengal's plains.

The results are legendary. Archways, pillars, and wall panels are decorated with intricate carvings illustrating scenes from the Indian epics Ramayana and Mahabharata, mythological events, and daily royal accounts.

**Must-Visit Monuments:**
* **Rasmancha:** Unique pyramidical structure built by King Bir Hambir in 1600 AD.
* **Madan Mohan Temple:** Richly decorated brick shrine showcasing Krishna legends.
* **Shyam Rai Temple:** Multi-pinnacled crown jewel of terracotta architectural patterns.

Bishnupur is also globally appreciated for its Dokra metal casting, terracotta wind-horses (Bankura Horse), and exquisite silk sarees.`,
    contentBn: `বাঁকুড়া জেলার বিষ্ণুপুর শহরটি চমৎকার টেরাকোটা বা পোড়ামাটির মন্দির এবং ঐতিহ্যবাহী বালুচরি শাড়ির জন্য বিখ্যাত। ১৬ থেকে ১৯ শতকের মধ্যে স্থানীয় মল্ল রাজারা পাথর না পাওয়ার কারণে স্থানীয় কাঁদামাটি পুড়িয়ে চমৎকার ইটের মন্দির নির্মাণ করেছিলেন।

এই সৃষ্টির তুলনা মেলা ভার! খিলান, খুঁটি এবং দীর্ঘ দেওয়ালে রামায়ণ ও মহাভারতের বীরত্বগাথা, হিন্দু পুরাণ এবং সমকালীন রাজকীয় জীবনের জীবন্ত কাহিনীর দৃশ্য ফুটিয়ে তোলা হয়েছে।

**অবশ্যই দর্শনীয় স্মৃতিস্তম্ভ:**
* **রাস মঞ্চ:** ১৬০০ খ্রিস্টাব্দে রাজা বীর হাম্বীর দ্বারা নির্মিত পিরামিড সদৃশ অনন্য অনন্য স্থাপত্য।
* **মদন মোহন মন্দির:** শ্রীকৃষ্ণের লীলা ফুটিয়ে তোলা পোড়ামাটির কারুকার্যময় ইট-মন্দির।
* **শ্যাম রায় মন্দির:** কারুকার্যময় পঞ্চ-চূড়া টেরাকোটা স্থাপত্যের শ্রেষ্ঠ নিদর্শন।

এছাড়াও বিষ্ণুপুর তার ডোকরা ধাতু শিল্প, বাঁকুড়ার পোড়ামাটির ঘোড়া এবং নজরকাড়া বালুচরি শাড়ির সুবাদে বিশ্ব দরবারে উচ্চ প্রশংসিত।`,
    category: 'History',
    categoryBn: 'ইতিহাস ও ঐতিহ্য',
    imageUrl: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?q=80&w=600',
    publishDate: '2026-05-15',
    author: 'Kailas Halder',
    likes: 35
  },
  {
    id: 'blog-3',
    title: 'The Sweet Magic: Why Bengal Sweets Form Our Soul',
    titleBn: 'মিষ্টির জাদু: যেভাবে মিষ্টিই বাঙালির আত্মা হয়ে উঠল',
    excerpt: 'Explore the sweet culinary heritage of Rasgulla, Sandesh, Mishti Doi, and the seasonal Nolen Gur of West Bengal.',
    excerptBn: 'রসগোল্লা, সন্দেশ, মিষ্টি দই এবং শীতের ঐতিহ্যবাহী নলেন গুড়ের চমৎকার ও জিভে জল আনা মিষ্টির ইতিহাস।',
    content: `No visitor can truly leave West Bengal without succumbing to its legendary sweet delicacies. Bengali confectioners transformed simple curdled milk (Chhena) into sublime artwork.

The state was officially awarded the GI (Geographical Indication) tag for 'Banglar Rosogolla'—spongy white cottage cheese balls soaked in light sugar syrup. But the sweet journey runs far deeper:
- **Sandesh:** Delicate, dry sweets crafted out of fresh chhena and flavored with cardamom, saffron, or date palm jaggery.
- **Mishti Doi:** Thick, caramelized sweet yogurt brewed slowly in earthen pots for a earthy smoky finish.
- **Nolen Gur:** Wild date-palm sap jaggery collected strictly during short winter mornings, generating legendary sweetness.

Food is sweet in Bengal, but sweeter is the hospitality that accompanies every plate.`,
    contentBn: `পশ্চিমবঙ্গে এসে এখানকার জগৎবিখ্যাত মিষ্টির স্বাদ না নিয়ে ফেরার কথা ভাবাই যায় না। বাংলার ময়রা বা কারিগরেরা সাধারণ ছানাকে হাতের জাদুতে এক অনন্য শিল্পকর্মে রূপান্তর করেছেন।

এরাজ্য আনুষ্ঠানিকভাবে 'বাংলার রসগোল্লা'র জন্য জিআই ট্যাগ পেয়েছে — যা রসে ভরা নরম তুলতুলে ছানার গোলক। তবে মিষ্টির রসদ আরও অনেক গভীর:
- **সন্দেশ:** তাজা ছানার সাথে এলাচ, জাফরান বা খেজুরের গুড় মিশিয়ে তৈরি সুস্বাদু শুকনো মিষ্টি।
- **মিষ্টি দই:** মাটির ভাঁড়ে ঐতিহ্যবাহী পদ্ধতিতে ধীরে ধীরে ঘন করে পাতা চমৎকার দই।
- **নলেন গুড়:** সোনালী খেজুরের রস যা শুধুমাত্র শীতের শুরুতে সংগ্রহ করে অপূর্ব অমৃতসম গুড় তৈরি করা হয়।

বাংলায় যেমন খাবার মিষ্টি, তেমনই মিষ্টি এখানকার মানুষের আন্তরিক অভ্যর্থনা ও আতিথেয়তা।`,
    category: 'Sweets',
    categoryBn: 'বাঙালি রকমারি মিষ্টি',
    imageUrl: 'https://images.unsplash.com/photo-1598902108854-10e335adac99?q=80&w=600',
    publishDate: '2026-06-01',
    author: 'Kailas Halder',
    likes: 67
  }
];

export const INITIAL_SCHEDULES: VesselSchedule[] = [
  // Ganganagar Services
  {
    id: 'sch-g1',
    route: 'Ganganagar Services',
    vesselName: 'M.V. Madhusudan',
    departureTime: '07:30 AM',
    arrivalTime: '08:15 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    specialNotice: 'Operating daily regular service',
    specialNoticeBn: 'নিয়মিত প্রতিদিনের পরিষেবা সচল আছে',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-g2',
    route: 'Ganganagar Services',
    vesselName: 'M.V. Vidyasagar',
    departureTime: '10:00 AM',
    arrivalTime: '10:45 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-g3',
    route: 'Ganganagar Services',
    vesselName: 'M.V. Madhusudan',
    departureTime: '01:30 PM',
    arrivalTime: '02:15 PM',
    status: 'Delayed',
    statusBn: 'বিলম্বিত',
    specialNotice: 'Delayed by 15 mins due to low tide',
    specialNoticeBn: 'ভাঁটার কারণে ১৫ মিনিট দেরিতে চলছে',
    lastUpdated: '1 hour ago'
  },
  {
    id: 'sch-g4',
    route: 'Ganganagar Services',
    vesselName: 'M.V. Vidyasagar',
    departureTime: '04:45 PM',
    arrivalTime: '05:30 PM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },

  // Kakdwip - Kachuberia
  {
    id: 'sch-k1',
    route: 'Kakdwip – Kachuberia',
    vesselName: 'M.B. Sagar Kheya-I',
    departureTime: '06:00 AM',
    arrivalTime: '06:40 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    specialNotice: 'First morning service from Lot No. 8',
    specialNoticeBn: 'লট ৮ থেকে শুরু হওয়া সকালের প্রথম ট্রিপ',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-k2',
    route: 'Kakdwip – Kachuberia',
    vesselName: 'M.V. Samudra Lux',
    departureTime: '08:30 AM',
    arrivalTime: '09:10 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-k3',
    route: 'Kakdwip – Kachuberia',
    vesselName: 'M.B. Sagar Kheya-II',
    departureTime: '11:15 AM',
    arrivalTime: '11:55 AM',
    status: 'Delayed',
    statusBn: 'বিলম্বিত',
    specialNotice: 'Slight delay expected under heavy silt navigation',
    specialNoticeBn: 'পলি জমার কারণে নদীপথে কিছুটা বিলম্ব হতে পারে',
    lastUpdated: '3 hours ago'
  },
  {
    id: 'sch-k4',
    route: 'Kakdwip – Kachuberia',
    vesselName: 'M.V. Samudra Lux',
    departureTime: '03:00 PM',
    arrivalTime: '03:40 PM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },

  // Harwood Point - Kachuberia
  {
    id: 'sch-hp1',
    route: 'Harwood Point – Kachuberia',
    vesselName: 'M.V. Sunderban Queen',
    departureTime: '07:00 AM',
    arrivalTime: '07:45 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-hp2',
    route: 'Harwood Point – Kachuberia',
    vesselName: 'M.V. Bhagirathi',
    departureTime: '12:30 PM',
    arrivalTime: '01:15 PM',
    status: 'Suspended',
    statusBn: 'স্থগিত',
    specialNotice: 'Temporarily suspended due to engine repairs',
    specialNoticeBn: 'ইঞ্জিন মেরামতের জন্য সাময়িকভাবে ট্রিপ স্থগিত রাখা হয়েছে',
    lastUpdated: '2 hours ago'
  },

  // Namkhana Ferry Service
  {
    id: 'sch-n1',
    route: 'Namkhana Ferry Service',
    vesselName: 'M.B. Hatania-Doania',
    departureTime: '08:00 AM',
    arrivalTime: '08:20 AM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },
  {
    id: 'sch-n2',
    route: 'Namkhana Ferry Service',
    vesselName: 'M.B. Hatania-Doania',
    departureTime: '12:00 PM',
    arrivalTime: '12:20 PM',
    status: 'On Time',
    statusBn: 'সঠিক সময়',
    lastUpdated: 'Today'
  },

  // Sagar Island Services
  {
    id: 'sch-s1',
    route: 'Sagar Island Services',
    vesselName: 'M.B. Gangasagar-III',
    departureTime: '09:30 AM',
    arrivalTime: '10:15 AM',
    status: 'Seasonal',
    statusBn: 'ঋতুগত',
    specialNotice: 'Special pilgrimage shuttle service active',
    specialNoticeBn: 'বিশেষ পুণ্যার্থীদের জন্য শাটল ভেসেল সচল আছে',
    lastUpdated: 'Today'
  }
];

export const DICTIONARY = {
  en: {
    title: 'Beautiful Bengal',
    slogan: 'West Bengal - The Sweetest Part Of India',
    welcome: 'Welcome to Beautiful Bengal',
    heroSub: 'Discover the Beauty, Culture, Heritage, Nature, and Traditions of West Bengal.',
    exploreButton: 'Explore Bengal',
    updatesButton: 'Latest Updates',
    home: 'Home',
    about: 'About Bengal',
    destinations: 'Destinations',
    timetable: 'Ferry Timetables',
    ganganagarTitle: 'Ganganagar Vessel Time Table',
    kakdwipTitle: 'Kakdwip subdivision Ferry Services',
    updateCenter: 'Daily Update Center',
    blogs: 'Blog & News',
    owner: 'Owner Info',
    contact: 'Contact Us',
    adminPanel: 'Admin Centre',
    adminOn: 'Admin Mode is active',
    adminOff: 'Switch to Admin Mode',
    adminSubTitle: 'Authorize and edit Ferry Timetables and Daily Blog CMS',
    mission: 'Our Mission',
    whyBengalSpecial: 'Why West Bengal is Special',
    missionText: '"Our aim is to portray the beauty, culture, heritage, traditions, tourism, and local life of Bengal to the world. Through Beautiful Bengal, we want people from across India and around the globe to discover the true beauty of West Bengal and experience its unique charm."',
    searchPlaceholder: 'Search destinations, news, or blog articles...',
    categoryAll: 'All Categories',
    readMore: 'Read Full Post',
    category: 'Category',
    date: 'Published Date',
    author: 'Author',
    vesselName: 'Vessel Name',
    departure: 'Departure Time',
    arrival: 'Arrival Time',
    status: 'Status',
    notices: 'Special Notices',
    lastUpdated: 'Last Updated',
    actions: 'Actions',
    edit: 'Edit',
    delete: 'Delete',
    addPost: 'Add Update/Blog Post',
    editPost: 'Edit Post',
    addVessel: 'Add Ferry Vessel Entry',
    editVessel: 'Edit Ferry Vessel Entry',
    save: 'Save Changes',
    cancel: 'Cancel',
    send: 'Send Message',
    nameLabel: 'Your name',
    emailLabel: 'Email address',
    phoneLabel: 'Phone number',
    messageLabel: 'Your message',
    submitting: 'Sending...',
    submitSuccess: 'Thank you for contacting us! We will get back to you soon.',
    ownerName: 'Kailas Halder',
    ownerRole: 'Founder & Administrator of Beautiful Bengal',
    ownerAddress: 'Kakdwip, South 24 Parganas, West Bengal, India – 743347',
    seoTab: 'SEO Stats & Sitemap',
    sitemapDesc: 'Dynamic automated XML Sitemap and Structured Schema JSON-LD metadata generator for Search Engines.',
    analyticsSim: 'Google Analytics simulated active on page views.'
  },
  bn: {
    title: 'বিউটিফুল বেঙ্গল',
    slogan: 'পশ্চিমবঙ্গ – ভারতের মিষ্টিতম অংশ',
    welcome: 'বিউটিফুল বেঙ্গলে আপনাকে স্বাগতম',
    heroSub: 'পশ্চিমবঙ্গের অপরূপ প্রাকৃতিক সৌন্দর্য, ঐতিহ্যবাহী সংস্কৃতি, সমৃদ্ধ ইতিহাস এবং সংস্কৃতির মেলবন্ধনে হারিয়ে যান।',
    exploreButton: 'বাংলা দর্শন করুন',
    updatesButton: 'আজকের আপডেট',
    home: 'হোম',
    about: 'বাংলা সম্পর্কে',
    destinations: 'দর্শনীয় স্থান',
    timetable: 'ফেরি সময়সূচী',
    ganganagarTitle: 'গঙ্গাসাগর নৌপরিবহন সময়সূচী',
    kakdwipTitle: 'কাকদ্বীপ মহকুমা ফেরি পরিষেবা',
    updateCenter: 'দৈনিক আপডেট কেন্দ্র',
    blogs: 'ব্লগ ও খবর',
    owner: 'ওয়েবসাইট মালিক',
    contact: 'যোগাযোগ করুন',
    adminPanel: 'অ্যাডমিন সেন্টার',
    adminOn: 'অ্যাডমিন মোড সচল আছে',
    adminOff: 'অ্যাডমিন মোডে প্রবেশ করুন',
    adminSubTitle: 'ফেরি সময়সূচী এবং দৈনিক ব্লগ CMS সম্পাদনা করার ক্ষমতা',
    mission: 'আমাদের লক্ষ্য',
    whyBengalSpecial: 'পশ্চিমবঙ্গ কেন অনন্য',
    missionText: '"আমাদের উদ্দেশ্য হল বাংলার প্রাকৃতিক রূপ, কৃষ্টি, গৌরবোজ্জ্বল ঐতিহ্য ও পর্যটনকে বিশ্বের দরবারে তুলে ধরা। বিউটিফুল বেঙ্গলের মাধ্যমে আমরা সারা বিশ্ব ও ভারতের মানুষের কাছে বাংলার অনন্য মাধুর্য ও আন্তরিকতা পৌঁছে দিতে চাই।"',
    searchPlaceholder: 'দর্শনীয় স্থান, খবর বা ব্লগ তথ্য খুঁজুন...',
    categoryAll: 'সব ক্যাটাগরি',
    readMore: 'সম্পূর্ণ পোস্ট পড়ুন',
    category: 'বিভাগ',
    date: 'প্রকাশের তারিখ',
    author: 'লেখক',
    vesselName: 'জলযানের নাম',
    departure: 'প্রস্থানের সময়',
    arrival: 'আগমনের সময়',
    status: 'অবস্থা',
    notices: 'বিশেষ নোটিশ',
    lastUpdated: 'সর্বশেষ পরিবর্তন',
    actions: 'অপশন',
    edit: 'সম্পাদনা',
    delete: 'বাতিল',
    addPost: 'নতুন ব্লগ বা আপডেট যোগ করুন',
    editPost: 'পোস্ট সম্পাদনা করুন',
    addVessel: 'নতুন ভেসেল সময়সূচি যোগ করুন',
    editVessel: 'ভেসেল সময়সূচি সম্পাদনা',
    save: 'তথ্য সংরক্ষণ করুন',
    cancel: 'বাতিল করুন',
    send: 'বার্তা পাঠান',
    nameLabel: 'আপনার নাম',
    emailLabel: 'ইমেইল ঠিকানা',
    phoneLabel: 'ফোন নম্বর',
    messageLabel: 'আপনার বার্তা/জিজ্ঞাসা',
    submitting: 'পাঠানো হচ্ছে...',
    submitSuccess: 'আমাদের সাথে যোগাযোগ করার জন্য ধন্যবাদ! আমরা শীঘ্রই আপনার সাথে যোগ দেব।',
    ownerName: 'কৈলাস হালদার',
    ownerRole: 'প্রতিষ্ঠাতা ও প্রশাসক, বিউটিফুল বেঙ্গল',
    ownerAddress: 'কাকদ্বীপ, দক্ষিণ ২৪ পরগনা, পশ্চিমবঙ্গ, ভারত – ৭৪৩৩৪৭',
    seoTab: 'SEO তথ্য ও সাইটম্যাপ',
    sitemapDesc: 'সার্চ ইঞ্জিনের জন্য স্বয়ংক্রিয় ডায়নামিক XML সাইটম্যাপ এবং স্কিমা মেটাডাটা (JSON-LD) জেনারেটর।',
    analyticsSim: 'গুগল অ্যানালিটিক্স অ্যাক্টিভ ট্র্যাকিং সিমুলেটেড।'
  }
};
