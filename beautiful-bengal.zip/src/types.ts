/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BlogPost {
  id: string;
  title: string;
  titleBn: string;
  excerpt: string;
  excerptBn: string;
  content: string;
  contentBn: string;
  category: 'Travel' | 'History' | 'Festivals' | 'Sweets' | 'Local Update' | 'Ferry' | 'Photography';
  categoryBn: string;
  imageUrl: string;
  publishDate: string;
  author: string;
  likes: number;
}

export interface VesselSchedule {
  id: string;
  route: string; // e.g., "Ganganagar Services"
  vesselName: string;
  departureTime: string;
  arrivalTime: string;
  status: 'On Time' | 'Delayed' | 'Suspended' | 'Seasonal';
  statusBn: string;
  specialNotice?: string;
  specialNoticeBn?: string;
  lastUpdated: string;
}

export interface TouristDestination {
  id: string;
  name: string;
  nameBn: string;
  image: string;
  description: string;
  descriptionBn: string;
  highlights: string[];
  highlightsBn: string[];
  category: 'Hills' | 'Forest' | 'Beaches' | 'Heritage' | 'Metropolitan';
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  date: string;
}

export type Language = 'en' | 'bn';

export interface SeoMetaData {
  title: string;
  description: string;
  keywords: string[];
}
